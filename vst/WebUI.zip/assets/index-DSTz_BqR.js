(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=(e,t,n,r,i,a,o={})=>({id:e,label:t,min:n,max:r,def:i,fmt:a,...o}),t=(e,t)=>({id:e,label:t}),n=[25,50,100,200,400,800,1600,3200,6500,13e3],r=e=>e>=1e3?`${e/1e3}k`:String(e),i=[0,7,10,3,12,5,15,7,2,10],a=[.2,.72,.35,.85,.28,.65,.9,.4,.55,.3],o=[.75,.25,.55,.3,.85,.2,.5,.35,.6,.45],s={envolvedor:{type:`envolvedor`,title:`Envolvedor`,inputs:[t(`entrada`,`Entrada 1`),t(`control`,`Entrada 2`)],outputs:[t(`s1`,`Salida 1`),t(`s2`,`Salida 2`)],params:[e(`nivel`,`Entrada 1`,0,1,0,`pct`,{ticks:[`mín.`,`máx.`]}),e(`mod`,`Entrada 2`,0,1,.9,`pct`,{ticks:[`mín.`,`máx.`]})]},aleator:{type:`aleator`,title:`Aleator`,inputs:[t(`pulso`,`Entrada`)],outputs:[t(`esc`,`Salida 1`),t(`suave`,`Salida 2`)],params:[]},anillo:{type:`anillo`,title:`Mod. Anular`,inputs:[t(`a`,`Entrada 1`),t(`b`,`Entrada 2`),t(`mod`,`Entrada 3`)],outputs:[t(`sal`,`Salida 1`),t(`sal2`,`Salida 2`)],params:[e(`nivel`,`Nivel`,0,1,.8,`pct`,{ticks:[`mín.`,`máx.`]})]},ruidor:{type:`ruidor`,title:`Ruidor`,inputs:[],outputs:[t(`blanco`,`blanco`),t(`rosa`,`rosa`)],params:[]},reverberal:{type:`reverberal`,title:`Reverberal`,inputs:[t(`e1`,`Entrada 1`),t(`e2`,`Entrada 2`)],outputs:[t(`sal`,`Salida 1`),t(`sal2`,`Salida 2`)],params:[e(`intensidad`,`intensidad`,0,1,.42,`pct`,{ticks:[`0`,`máx.`]}),e(`tiempo`,`tiempo`,0,1,.68,`pct`,{ticks:[`0`,`máx.`]})]},integrador:{type:`integrador`,title:`Integrador Envolv.`,inputs:[t(`pulso`,`pulso`)],outputs:[t(`sal`,`env. 1`),t(`sal2`,`env. 2`),t(`pulsoSal`,`pulso`)],params:[e(`ataque`,`ataque`,.005,5,.01,`s`,{curve:`log`,ticks:[`5ms.`,`5seg.`]}),e(`modo`,`Disparo`,0,1,0,`choice`,{control:`slide-sw`,choices:[`ext.`,`int.`]}),e(`duracion`,`duración`,.005,5,.09,`s`,{curve:`log`,ticks:[`5ms.`,`5seg.`]}),e(`decaimiento`,`decaimiento`,.005,5,.22,`s`,{curve:`log`,ticks:[`5ms.`,`5seg.`]})]},oscilador:{type:`oscilador`,title:`Oscilador`,inputs:[t(`frec`,`frecuencia`),t(`mod`,`modular en frec.`)],outputs:[t(`sen`,`~`),t(`tri`,`∧`),t(`rampa`,`⩘`),t(`cuad`,`⊓`)],params:[e(`frecuencia`,`frecuencia`,5,2e4,261.63,`hz`,{curve:`log`,control:`knob-white`,ticks:[`5hz.`,`20khz.`]}),e(`fino`,`aj. fino`,-2,2,0,`st`,{ticks:[``,``]}),e(`ancho`,`ancho`,.05,.95,.5,`pct`,{ticks:[`⊔`,`⊓`]}),e(`modulador`,`modular en frec.`,0,1,0,`pct`,{control:`knob-white-sm`,ticks:[`0`,`máx.`]}),e(`modoMod`,`Acoplamiento`,0,1,0,`choice`,{control:`slide-sw`,choices:[`dir.`,`rec.`]})]},filtrov:{type:`filtrov`,title:`Filtro-V`,inputs:[t(`entrada`,`Entrada`),t(`anchoCv`,`ancho`),t(`control`,`Centro`),t(`mod`,`modulación`)],outputs:[t(`bajos`,`baj.`),t(`altos`,`alt.`),t(`banda`,`banda`)],params:[e(`ancho`,`ancho`,0,1,.35,`pct`,{ticks:[`mín.`,`máx.`]}),e(`corte`,`Corte`,-2,2,0,`oct`,{control:`fader`}),e(`centro`,`Centro`,5,15e3,600,`hz`,{curve:`log`,control:`knob-white`,ticks:[`5Hz`,`15kHz`]}),e(`modulacion`,`modulación`,0,5,2.2,`oct`,{control:`fader`})]},filtroo:{type:`filtroo`,title:`Filtro-O`,inputs:[t(`entrada`,`Entrada`)],outputs:[t(`suma`,`Suma`),...n.map((e,n)=>t(`b${n}`,r(e)))],params:[e(`corte`,`Corte`,0,1,.85,`pct`,{control:`fader-v`}),...n.map((t,n)=>e(`g${n}`,r(t),0,1,.7,`pct`,{control:`fader`})),e(`suma`,`Suma`,0,1,.72,`pct`,{control:`fader`})]},pulsador:{type:`pulsador`,title:`Pulsador`,inputs:[t(`inicio`,`inicio`),t(`fin`,`fin`),t(`anchoCv`,`Pulsos`),t(`relojCv`,`reloj`)],outputs:[t(`pulsos`,`Pulsos 1`),t(`pulsos2`,`Pulsos 2`),t(`inv`,`Pulsos 3`)],params:[e(`ancho`,`Pulsos`,.05,.95,.35,`pct`,{ticks:[`0`,`100`]}),e(`reloj`,`reloj`,.1,40,4.5,`hz`,{curve:`log`,control:`knob-white-sm`,ticks:[`mín.`,`máx.`]})]},secuenciador:{type:`secuenciador`,title:`S E C U E N C I A D O R`,inputs:[t(`pulso`,`pulsos`),t(`reinicio`,`reinicio`)],outputs:[t(`pulsoSal`,`Salida`),t(`a`,`Fila 1`),t(`b`,`Fila 2`),t(`c`,`Fila 3`),t(`volt`,`voltaje`),...Array.from({length:10},(e,n)=>t(`st${n}`,`Paso ${n+1}`))],params:[...Array.from({length:30},(t,n)=>{let r=Math.floor(n/10),s=n%10,c=r===0?i[s]/24:r===1?a[s]:o[s];return e(`s${n}`,`${`ABC`[r]}${s+1}`,0,1,c,`pct`,{control:`knob-sm`})}),...Array.from({length:10},(t,n)=>e(`sw${n}`,`Paso ${n+1}`,0,1,1,`choice`,{control:`step-sw`,choices:[`0`,`1`]}))]},teclado:{type:`teclado`,title:`Teclado`,inputs:[],outputs:[t(`volt`,`Voltaje`),t(`pulso`,`Pulso`)],params:[e(`portamento`,`Portamento`,0,2,0,`s`,{ticks:[`mín.`,`máx.`]})]},salida:{type:`salida`,title:`Salida`,stereo:!0,inputs:[t(`izq`,`Izquierda`),t(`der`,`Derecha`)],outputs:[],params:[e(`volumen`,`Volumen`,0,1,.65,`pct`,{ticks:[`mín.`,`máx.`]})]}},c=[{id:`envolvedor`,type:`envolvedor`,area:`env`},{id:`aleator`,type:`aleator`,area:`ale`},{id:`anillo`,type:`anillo`,area:`ani`},{id:`ruidor`,type:`ruidor`,area:`rui`},{id:`reverberal`,type:`reverberal`,area:`rev`},{id:`integrador`,type:`integrador`,area:`int`},{id:`osc1`,type:`oscilador`,area:`os1`},{id:`osc2`,type:`oscilador`,area:`os2`},{id:`filtrov`,type:`filtrov`,area:`fiv`},{id:`filtroo`,type:`filtroo`,area:`fio`},{id:`pulsador`,type:`pulsador`,area:`pul`},{id:`secuenciador`,type:`secuenciador`,area:`seq`},{id:`teclado`,type:`teclado`,area:`tec`},{id:`salida`,type:`salida`,area:`sal`}];function l(e){return Object.fromEntries(s[e].params.map(e=>[e.id,e.def]))}var u={Envolvedor:`Enveloper`,Aleator:`Randomizer`,"Mod. Anular":`Ring Mod.`,Ruidor:`Noise Gen.`,Reverberal:`Reverberator`,"Integrador Envolv.":`Env. Integrator`,Oscilador:`Oscillator`,"Filtro-V":`V-Filter`,"Filtro-O":`O-Filter`,Pulsador:`Pulser`,Secuenciador:`Sequencer`,"S E C U E N C I A D O R":`S E Q U E N C E R`,Teclado:`Keyboard`,Salida:`Output`,Entradas:`Inputs`,Salidas:`Outputs`,entrada:`input`,salida:`output`,Entrada:`Input`,"Entrada 1":`Input 1`,"Entrada 2":`Input 2`,"Entrada 3":`Input 3`,"Entrada A":`Input A`,"Entrada B":`Input B`,"Salida 1":`Output 1`,"Salida 2":`Output 2`,Control:`Control`,Mínimo:`Min`,Máximo:`Max`,Escalón:`Stepped`,Suave:`Smooth`,Velocidad:`Rate`,Nivel:`Level`,Portadora:`Carrier`,Blanco:`White`,blanco:`white`,Rosa:`Pink`,rosa:`pink`,Intensidad:`Intensity`,intensidad:`intensity`,"Intensid.":`Intensity`,Tiempo:`Decay`,tiempo:`time`,Pulso:`Pulse`,pulso:`pulse`,pulsos:`pulses`,Pulsos:`Pulses`,"Pulsos 1":`Pulses 1`,"Pulsos 2":`Pulses 2`,"Pulsos 3":`Pulses 3`,"env.":`env.`,"env. 1":`env. 1`,"env. 2":`env. 2`,ataque:`attack`,duración:`hold`,decaimiento:`decay`,"ext.":`ext.`,"int.":`int.`,Disparo:`Trigger`,frecuencia:`frequency`,Frecuencia:`Frequency`,"aj. fino":`fine tune`,ancho:`width`,Ancho:`Width`,"modular en frec.":`freq. mod.`,"dir.":`dir.`,"d.":`dir.`,"rec.":`rect.`,Corte:`Cutoff`,Centro:`Center`,modulación:`modulation`,"baj.":`low`,"alt.":`high`,banda:`band`,Suma:`Sum`,inicio:`start`,fin:`stop`,reloj:`clock`,reinicio:`reset`,"Fila 1":`Row 1`,"Fila 2":`Row 2`,"Fila 3":`Row 3`,voltaje:`voltage`,Voltaje:`Voltage`,Portamento:`Glide`,Izquierda:`Left`,Derecha:`Right`,Volumen:`Volume`,"mín.":`min.`,"máx.":`max.`,"5ms.":`5ms.`,"5seg.":`5sec.`,Rápida:`Fast`,Media:`Med`,Lenta:`Slow`};function d(e,t){return t===`es`?e:u[e]??e}var f={es:{subtitle:`Raúl Pavón Sarrelangue · México · c. 1960`,byLabel:`Recreación virtual por`,presets:`Parches`,dimCables:`Atenuar cables`,clearCables:`Sin cables`,unpatchedDesc:`Gabinete desconectado: arrastra desde cualquier conector para crear tu propio parche.`,info:`Información`,manual:`Manual Ilustrado`,powerOn:`Encender`,powerOff:`Activo`,keysHintHtml:`Teclas <kbd>A</kbd>–<kbd>Ñ</kbd><br><kbd>Z</kbd>/<kbd>X</kbd> octava: <b id="octave-label">C3</b>`,footerHtml:`Arrastra desde un conector para tender un cable · arrastra desde una entrada ocupada para desconectar · perillas: arrastre vertical (Shift = fino, doble clic = inicial).<br />Reconstrucción históricamente informada del Omnifón (c. 1960–64 / 1981). No es una emulación de circuito: no existen esquemáticos publicados.<br /><a href="https://extasisrecords.bandcamp.com" target="_blank" rel="noopener noreferrer" class="footer-link">@extasisrecords</a>`,close:`Cerrar`,loadFigPreset:`Cargar preset Fig. IV.38`,audioError:`No se pudo iniciar el audio: `},en:{subtitle:`Raúl Pavón Sarrelangue · Mexico · c. 1960`,byLabel:`Virtual recreation by`,presets:`Patches`,dimCables:`Dim cables`,clearCables:`Unpatch all`,unpatchedDesc:`Unpatched cabinet: drag from any jack to build your own patch.`,info:`History & Info`,manual:`Illustrated Manual`,powerOn:`Power On`,powerOff:`Running`,keysHintHtml:`Keys <kbd>A</kbd>–<kbd>;</kbd><br><kbd>Z</kbd>/<kbd>X</kbd> octave: <b id="octave-label">C3</b>`,footerHtml:`Drag from any jack to patch a cable · drag from an occupied input to unplug · knobs: vertical drag (Shift = fine, double-click = reset).<br />Historically informed reconstruction of the Omnifón (c. 1960–64 / 1981). Not a circuit-level clone: no schematics have been published.<br /><a href="https://extasisrecords.bandcamp.com" target="_blank" rel="noopener noreferrer" class="footer-link">@extasisrecords</a>`,close:`Close`,loadFigPreset:`Load Fig. IV.38 preset`,audioError:`Could not start audio: `}};function p(e,t){return e===`en`?`
      <div class="modal-header">
        <div>
          <p class="modal-kicker">History & Technical Context</p>
          <h2>The Omnifón of Raúl Pavón Sarrelangue</h2>
        </div>
        <button type="button" class="modal-close" data-close-modal aria-label="Close">✕</button>
      </div>
      <div class="modal-body">
        <p class="modal-lead">
          The <strong>Omnifón</strong> (meaning <em>“all sounds”</em>) is recognized as the <strong>first analog voltage-controlled synthesizer designed and built in Mexico</strong>, and one of the earliest instruments of its kind developed independently in Latin America alongside pioneers such as Robert Moog, Donald Buchla, Paolo Ketoff, and Erkki Kurenniemi.
        </p>

        <div class="modal-grid">
          <div class="modal-text">
            <h3>1. Pioneer & Origins (1958–1970)</h3>
            <p>
              Engineered by Mexican electrical/computing pioneer and composer <strong>Raúl Pavón Sarrelangue</strong> (1927–2008)—who authored Mexico’s first computing paper at a U.S. national conference in 1958 and studied electroacoustic music in Milan and Cologne—the project began after a 1958 <em>musique concrète</em> concert in Paris inspired him to build a 1-octave magnetic tape-loop keyboard.
            </p>
            <p>
              Between <strong>1960 and 1964</strong> (dated 1960 by Pavón and Ricardo Dal Farra; ~1964 by Gabriel Pareyón), Pavón built the first Omnifón prototype. Although local electronics manufacturers declined commercial production, his work led directly to the founding in <strong>1970</strong> of Mexico’s first <strong>Electronic Music Laboratory</strong> at the National Conservatory of Music (CNM) alongside composer Héctor Quintanar and backed by Carlos Chávez.
            </p>

            <h3>2. Two Stages Under One Name — and Disambiguation</h3>
            <ul>
              <li><strong>The 1960s Prototype:</strong> A compact voltage-controlled subtractive instrument featuring a remarkably pure continuous oscillator (<code>10 Hz – 20 kHz</code>, sine, square, and ramp waves), white noise, voltage-controlled filtering, envelope shaping, and keyboard control.</li>
              <li><strong>The 1981 Modular System:</strong> In his landmark book <em>La electrónica en la música… y en el arte</em> (CENIDIM, 1981, Ch. IV), Pavón expanded and documented the Omnifón as a complete didactic modular studio—featuring dual VCOs, ring modulation (<em>Mod. Anular</em>), stepped/smooth random generator (<em>Aleator</em>), voltage and 10-band octave filters (<em>Filtro-V</em>, <em>Filtro-O</em>), reverberation, pulser clock, and a 3×10 analog sequencer.</li>
              <li><strong>Not to be confused with the Icofón (1976):</strong> A separate audiovisual instrument created later by Pavón that translated sound into laser/oscilloscope color projections.</li>
            </ul>

            <h3>3. About This Virtual Reconstruction</h3>
            <p>
              Because the Omnifón was never mass-produced, <strong>no electronic circuit schematics, bills of materials, or certified dry recordings have been published</strong>. This web synthesizer is a <em>historically informed DSP reconstruction</em>: every module runs at audio rate inside its own <code>AudioWorkletProcessor</code>, faithfully following Pavón’s documented panel architecture, signal ranges, and patching workflow.
            </p>
            <div class="modal-fig-actions" style="margin-top:14px;">
              <a href="./investigacion.html" target="_blank" rel="noopener noreferrer" class="bar-btn" style="display:inline-flex;text-decoration:none;">
                Open Annex: Complete Documentary Research (Tables &amp; Graphics) →
              </a>
            </div>
          </div>

          <figure class="modal-figure">
            <img src="${t}" alt="Figura IV.38 Un ejemplo del alambrado en el omnifón — Raúl Pavón, 1981" />
            <figcaption>
              <strong>Figure IV.38 — “An example of wiring on the Omnifón”</strong><br />
              Original plate from Raúl Pavón Sarrelangue’s book <em>La electrónica en la música… y en el arte</em> (SEP / INBA-CENIDIM, Mexico, 1981). Notice how one voice pairs the 10-step melodic sequence and ring modulator through the octave filter bank, while a second voice routes pink noise into the voltage filter under programmed sequencer control.
              <div class="modal-fig-actions">
                <button type="button" class="bar-btn" data-load-fig>Load Preset #1 (Fig. IV.38)</button>
              </div>
            </figcaption>
          </figure>
        </div>

        <div class="modal-footer">
          <span>Virtual instrument created by <a href="https://www.instagram.com/laurorobles/" target="_blank" rel="noopener noreferrer">@laurorobles</a></span>
          <span>Sources: R. Pavón (CENIDIM, 1981) · R. Dal Farra (UQAM, 2006) · M. Rocha Iturbide · M. Matus Lerner (NIME, 2019)</span>
        </div>
      </div>
    `:`
    <div class="modal-header">
      <div>
        <p class="modal-kicker">Historia y contexto técnico</p>
        <h2>El Omnifón de Raúl Pavón Sarrelangue</h2>
      </div>
      <button type="button" class="modal-close" data-close-modal aria-label="Cerrar">✕</button>
    </div>
    <div class="modal-body">
      <p class="modal-lead">
        El <strong>Omnifón</strong> (<em>«todos los sonidos»</em>) es reconocido como el <strong>primer sintetizador analógico controlado por voltaje diseñado y construido en México</strong>, desarrollado de manera independiente en paralelo a los primeros instrumentos de Robert Moog, Donald Buchla, Paolo Ketoff y Erkki Kurenniemi.
      </p>

      <div class="modal-grid">
        <div class="modal-text">
          <h3>1. Pionero y origen (1958–1970)</h3>
          <p>
            Creado por el ingeniero electricista, pionero del cómputo y compositor mexicano <strong>Raúl Pavón Sarrelangue</strong> (1927–2008) —autor de la primera ponencia mexicana de computación en EE. UU. en 1958 y formado en los estudios electroacústicos de Milán y Colonia—, su búsqueda inició tras escuchar música concreta en París en 1958, construyendo primero un teclado de una octava basado en cintas magnéticas en bucle.
          </p>
          <p>
            Entre <strong>1960 y 1964</strong> (fechado en 1960 por Pavón y Ricardo Dal Farra; hacia 1964 por Gabriel Pareyón), Pavón diseñó y construyó el prototipo del Omnifón. Aunque la industria nacional no se interesó en fabricarlo comercialmente, este trabajo desembocó en la fundación en <strong>1970</strong> del primer <strong>Laboratorio de Música Electrónica</strong> de México en el Conservatorio Nacional de Música (CNM), junto con Héctor Quintanar y con el respaldo de Carlos Chávez.
          </p>

          <h3>2. Dos etapas bajo el mismo nombre (y deslinde histórico)</h3>
          <ul>
            <li><strong>El prototipo de los años 60:</strong> Sintetizador sustractivo controlado por voltaje con un oscilador continuo de gran pureza armónica (<code>10 Hz – 20 kHz</code> en ondas senoidal, cuadrada y rampa), generador de ruido blanco, filtro por voltaje, envolvente y teclado.</li>
            <li><strong>El sistema modular de 1981:</strong> En el capítulo IV de su libro fundamental <em>La electrónica en la música… y en el arte</em> (CENIDIM, 1981), Pavón sistematizó el Omnifón como un gabinete modular completo: doble oscilador, modulador anular (<em>Mod. Anular</em>), generador aleatorio (<em>Aleator</em>), filtro por voltaje (<em>Filtro-V</em>), banco de 10 octavas (<em>Filtro-O</em>), reverberador, reloj (<em>Pulsador</em>) y secuenciador analógico de 3×10 pasos.</li>
            <li><strong>Deslinde del Icofón (1976):</strong> Instrumento audiovisual distinto creado posteriormente por Pavón para traducir sonido electrónico en proyecciones cromáticas mediante osciloscopio.</li>
          </ul>

          <h3>3. Sobre esta reconstrucción virtual</h3>
          <p>
            Al tratarse de un desarrollo de taller no comercializado, <strong>no existen esquemáticos electrónicos de circuito ni grabaciones secas certificadas en fuentes públicas</strong>. Esta versión es una <em>reconstrucción históricamente informada en DSP</em>: cada módulo opera a frecuencia de audio en su propio <code>AudioWorkletProcessor</code>, respetando la arquitectura de paneles, rangos y flujo de alambrado documentados por su creador.
          </p>
          <div class="modal-fig-actions" style="margin-top:14px;">
            <a href="./investigacion.html" target="_blank" rel="noopener noreferrer" class="bar-btn" style="display:inline-flex;text-decoration:none;">
              Abrir Anexo: Investigación Documental Completa (Tablas y Gráficos) →
            </a>
          </div>
        </div>

        <figure class="modal-figure">
          <img src="${t}" alt="Figura IV.38 Un ejemplo del alambrado en el omnifón — Raúl Pavón, 1981" />
          <figcaption>
            <strong>Figura IV.38 — «Un ejemplo del alambrado en el omnifón»</strong><br />
            Lámina original del libro <em>La electrónica en la música… y en el arte</em> de Raúl Pavón Sarrelangue (SEP / INBA-CENIDIM, México, 1981). En este parche documental, una voz articula la secuencia melódica y la modulación anular a través del banco de octavas, mientras una segunda voz procesa ruido rosa con filtrado programado desde el secuenciador.
            <div class="modal-fig-actions">
              <button type="button" class="bar-btn" data-load-fig>Cargar Preset #1 (Fig. IV.38)</button>
            </div>
          </figcaption>
        </figure>
      </div>

      <div class="modal-footer">
        <span>Recreación virtual desarrollada por <a href="https://www.instagram.com/laurorobles/" target="_blank" rel="noopener noreferrer">@laurorobles</a></span>
        <span>Fuentes: R. Pavón (CENIDIM, 1981) · R. Dal Farra (UQAM, 2006) · M. Rocha Iturbide · M. Matus Lerner (NIME, 2019)</span>
      </div>
    </div>
  `}function m(e,t){return e===`en`?`
      <div class="modal-header">
        <div>
          <p class="modal-kicker">Interactive Guide & User Manual</p>
          <h2>Omnifón Virtual · Complete Operating Guide</h2>
        </div>
        <button type="button" class="modal-close" data-close-modal aria-label="Close">✕</button>
      </div>
      <div class="modal-body manual-content">
        <div class="manual-hero">
          <img src="${t}" alt="Original Omnifón Hardware Console" class="manual-hero-img" />
          <div class="manual-hero-caption">
            <strong>Recreation vs. Original Hardware:</strong> Front view of the Omnifón synthesizer built by Raúl Pavón Sarrelangue (CENIDIM, Mexico). Notice the exact 14-module layout, panel typography, and control arrangements replicated in this software.
          </div>
        </div>

        <nav class="manual-quick-nav">
          <a href="#man-quickstart">1. Quickstart</a>
          <a href="#man-gestures">2. Controls & Patching</a>
          <a href="#man-modules">3. Module Reference</a>
          <a href="#man-patches">4. Included Patches</a>
          <a href="#man-vst">5. VST Roadmap</a>
        </nav>

        <section id="man-quickstart" class="manual-section">
          <h3>1. Quickstart Guide</h3>
          <div class="steps-grid">
            <div class="step-card">
              <span class="step-num">1</span>
              <h4>Power On Audio</h4>
              <p>Click <strong>Power On</strong> in the top bar. The red indicator lamp will illuminate and the Web Audio DSP engine will immediately activate.</p>
            </div>
            <div class="step-card">
              <span class="step-num">2</span>
              <h4>Audition 8 Patches</h4>
              <p>Click on any button in the <strong>Patches</strong> bar. Patch #1 is the historic <strong>Fig. IV.38</strong> layout. Use patches #2 or #6 to play melodies directly from the keyboard.</p>
            </div>
            <div class="step-card">
              <span class="step-num">3</span>
              <h4>Play Notes</h4>
              <p>Use your mouse on the 5-octave keybed, computer keys (<kbd>A</kbd>–<kbd>;</kbd>), or connect any USB/Bluetooth MIDI keyboard (Web MIDI auto-detects instantly).</p>
            </div>
          </div>
        </section>

        <section id="man-gestures" class="manual-section">
          <h3>2. Patch Cables & Control Gestures</h3>
          <div class="manual-grid-2col">
            <div class="manual-panel-box">
              <h4>Connecting & Unpatching</h4>
              <ul>
                <li><strong>Draw Cable:</strong> Click & drag from any jack (input or output). Connecting to an already occupied input will replace it cleanly.</li>
                <li><strong>Unplug Cable:</strong> Click and drag from an <em>occupied input jack</em> and release in empty space to remove it.</li>
                <li><strong>Multiple Destinations:</strong> Any output jack can feed multiple inputs simultaneously.</li>
                <li><strong>Dim Cables:</strong> Click <strong>Dim Cables</strong> in the top header to make wires translucent while adjusting knobs.</li>
              </ul>
            </div>
            <div class="manual-panel-box">
              <h4>Knob & Slider Manipulation</h4>
              <ul>
                <li><strong>Knobs:</strong> Drag vertically or use mouse wheel.</li>
                <li><strong>Fine Tune:</strong> Hold <kbd>Shift</kbd> while dragging for high-precision tuning.</li>
                <li><strong>Reset:</strong> Double-click any knob or slider to return to its default position.</li>
                <li><strong>O-Filter Sliders:</strong> Horizontal faders control 10 individual octave bands plus Master Sum.</li>
              </ul>
            </div>
          </div>
        </section>

        <section id="man-modules" class="manual-section">
          <h3>3. Visual Module Reference (14 Units)</h3>
          
          <div class="module-cards-flow">
            <div class="module-card">
              <div class="module-badge">Row 1 · Audio & FX</div>
              <h4>ENVOLVEDOR (VCA)</h4>
              <p>Voltage-controlled dual amplifier. <code>Entrada 1</code> sets baseline bleed; <code>Entrada 2</code> sets dynamic gain governed by envelope CV.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 1 · Random</div>
              <h4>ALEATOR (Random S&H)</h4>
              <p>Stepped & smooth voltage generator. Oscillates autonomously or samples new values upon incoming pulse triggers.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 1 · FX</div>
              <h4>MOD. ANULAR (Ring Modulator)</h4>
              <p>Four-quadrant analog multiplier creating metallic sidebands and inharmonic bell partials with internal or external carrier.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 1 · Source</div>
              <h4>RUIDOR (Noise Source)</h4>
              <p>Calibrated noise generator providing simultaneous flat <strong>White</strong> and −3dB/oct <strong>Pink</strong> noise outputs.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 1 · FX</div>
              <h4>REVERBERAL (Dual Spring Reverb)</h4>
              <p>Summing reverb processor with dedicated <code>intensidad</code> (wet/dry depth) and <code>tiempo</code> (dispersion decay) controls.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 2 · Modulation</div>
              <h4>INTEGRADOR ENVOLV. (Trapezoidal Env)</h4>
              <p>3-stage envelope: <code>ataque</code>, <code>duración</code> (hold), and <code>decaimiento</code> (decay). Toggle <code>ext.</code> for gate triggers or <code>int.</code> for continuous trapezoidal LFO cycling.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 2 · Audio Core</div>
              <h4>OSCILADOR 1 & 2 (Dual VCOs)</h4>
              <p>Continuous 5Hz–20kHz oscillators with Sine (<code>∿</code>), Triangle (<code>∧</code>), Ramp (<code>⩘</code>), and Variable Pulse (<code>⊓</code>). Includes linear/exponential FM inputs with Direct/Rectified selector.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 2 · Filter</div>
              <h4>FILTRO-V (Voltage-Controlled Filter)</h4>
              <p>State-variable filter with simultaneous Low-pass (<code>baj.</code>), High-pass (<code>alt.</code>), and Band-pass (<code>banda</code>) outputs, resonance bandwidth control, and center CV modulation.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 2 · Filter Bank</div>
              <h4>FILTRO-O (10-Band Octave Bank)</h4>
              <p>Fixed-Q inductor-style filter bank at 25, 50, 100, 200, 400, 800, 1.6k, 3.2k, 6.5k, and 13kHz, each with individual direct output tap and master Sum slider.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 3 · Timing</div>
              <h4>PULSADOR (Master Clock)</h4>
              <p>Variable pulse train generator (0.1Hz – 40Hz) with Start/Stop push buttons, pulse width CV, and anti-phase inverted pulse output.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Row 3 · Matrix</div>
              <h4>S E C U E N C I A D O R (3×10 Sequencer)</h4>
              <p>10-step, 3-row CV matrix. Row 1 is quantized to musical semitones; Rows 2 & 3 provide continuous microtonal voltages. Jump/loop any step by cabling step outputs to <code>reinicio</code>.</p>
            </div>

            <div class="module-card">
              <div class="module-badge">Bottom · Input & Output</div>
              <h4>TECLADO & SALIDA</h4>
              <p>5-octave keybed with adjustable glide portamento and pitch CV + gate. Master output stage includes volume limiter and real-time CRT-style oscilloscope.</p>
            </div>
          </div>
        </section>

        <section id="man-patches" class="manual-section">
          <h3>4. Factory Patches & Patching Recipes</h3>
          <div class="patches-overview-grid">
            <div class="patch-guide-item">
              <strong>1 · Fig. IV.38:</strong> Raúl Pavón’s exact 1981 CENIDIM book diagram. Dual-voice arrangement: ring-modulated sequence through octave filter bank, plus stepped noise bursts on Filtro-V.
            </div>
            <div class="patch-guide-item">
              <strong>2 · Teclado:</strong> Expressive lead voice ready to play from keyboard or MIDI. Features gentle vibrato from OSC 2 and stereo spring reverb.
            </div>
            <div class="patch-guide-item">
              <strong>3 · Bajo 8p:</strong> Hypnotic 8-step analog bassline with automated filter resonance modulation per step.
            </div>
            <div class="patch-guide-item">
              <strong>4 · Campanas:</strong> Algorithmic bell chimes in 7/8 time using cross-coupled ring modulation and formant peaks.
            </div>
            <div class="patch-guide-item">
              <strong>5 · Aleatorio:</strong> Self-generating ambient soundscape driven by cyclical trapezoid envelopes and pseudo-random voltages.
            </div>
            <div class="patch-guide-item">
              <strong>6 · Formantes:</strong> Vocal choral synthesizer mimicking human vowels (A, E, I, O, U) playable poly-tonally via keyboard CV.
            </div>
            <div class="patch-guide-item">
              <strong>7 · Percusión:</strong> 10-step analog drum groove with punchy kick transients and metallic noise hats.
            </div>
            <div class="patch-guide-item">
              <strong>8 · Cosmos:</strong> Deep space drone combining slow FM sweeps, high-resonance self-oscillation, and expansive stereo reverb.
            </div>
          </div>
        </section>

        <section id="man-vst" class="manual-section">
          <h3>5. Native VST / AU / CLAP Roadmap</h3>
          <p>
            A dedicated porting initiative is underway to bring the Omnifón into digital audio workstations (DAWs) as a 64-bit VST3, Audio Unit, and CLAP plugin using JUCE and C++20. For technical details, parameter tree architecture, and release milestones, consult the official <a href="https://github.com/laurorobles/Omnifon/blob/main/docs/ROADMAP_VST.md" target="_blank" rel="noopener noreferrer">VST Roadmap in the GitHub repository</a>.
          </p>
        </section>

        <div class="modal-footer">
          <span>Omnifón Virtual created by <a href="https://www.instagram.com/laurorobles/" target="_blank" rel="noopener noreferrer">@laurorobles</a></span>
          <span>Source Code: <a href="https://github.com/laurorobles/Omnifon" target="_blank" rel="noopener noreferrer">github.com/laurorobles/Omnifon</a></span>
        </div>
      </div>
    `:`
    <div class="modal-header">
      <div>
        <p class="modal-kicker">Guía interactiva y manual de usuario</p>
        <h2>Omnifón Virtual · Manual Completo de Uso</h2>
      </div>
      <button type="button" class="modal-close" data-close-modal aria-label="Cerrar">✕</button>
    </div>
    <div class="modal-body manual-content">
      <div class="manual-hero">
        <img src="${t}" alt="Gabinete original del Omnifón de Raúl Pavón" class="manual-hero-img" />
        <div class="manual-hero-caption">
          <strong>Aparato original vs. Recreación virtual:</strong> Fotografía frontal del sintetizador Omnifón construido por Raúl Pavón Sarrelangue (CENIDIM, México). Observa la correspondencia idéntica de sus 14 módulos, tipografías, selectores y controles reproducidos en esta recreación.
        </div>
      </div>

      <nav class="manual-quick-nav">
        <a href="#man-quickstart">1. Inicio rápido</a>
        <a href="#man-gestures">2. Cables y controles</a>
        <a href="#man-modules">3. Módulos explicados</a>
        <a href="#man-patches">4. Los 8 parches</a>
        <a href="#man-vst">5. Plan VST</a>
      </nav>

      <section id="man-quickstart" class="manual-section">
        <h3>1. Inicio rápido en 3 pasos</h3>
        <div class="steps-grid">
          <div class="step-card">
            <span class="step-num">1</span>
            <h4>Encender el audio</h4>
            <p>Haz clic en el botón <strong>Encender</strong> en la barra superior. La lámpara roja se iluminará y el motor de síntesis Web Audio comenzará a sonar de inmediato.</p>
          </div>
          <div class="step-card">
            <span class="step-num">2</span>
            <h4>Explorar los 8 parches</h4>
            <p>Haz clic en cualquiera de los botones de la barra <strong>Parches</strong>. El preset #1 es la recreación exacta de la <strong>Fig. IV.38</strong> del libro de 1981. Para tocar melodías libres, elige <strong>2 · Teclado</strong>.</p>
          </div>
          <div class="step-card">
            <span class="step-num">3</span>
            <h4>Tocar notas y experimentar</h4>
            <p>Toca con el ratón o pantalla táctil en el teclado de 5 octavas, usa tu teclado de computadora (<kbd>A</kbd>–<kbd>Ñ</kbd>) o conecta un controlador MIDI USB (se detecta automáticamente).</p>
          </div>
        </div>
      </section>

      <section id="man-gestures" class="manual-section">
        <h3>2. Alambrado de cables y gestos de control</h3>
        <div class="manual-grid-2col">
          <div class="manual-panel-box">
            <h4>Conexión y desconexión de cables</h4>
            <ul>
              <li><strong>Tender un cable:</strong> Haz clic y arrastra desde cualquier conector (entrada o salida). Al soltar sobre otro conector compatible se enlazará automáticamente.</li>
              <li><strong>Desenchufar / mover:</strong> Haz clic sobre una <em>entrada ocupada</em> y arrastra. Si sueltas en un área vacía el cable se elimina; si lo llevas a otra entrada se reubica.</li>
              <li><strong>Múltiples destinos:</strong> Una sola salida puede alimentar simultáneamente varias entradas (distribución pasiva mult).</li>
              <li><strong>Atenuar cables:</strong> Pulsa el botón <strong>Atenuar cables</strong> en la barra superior para hacer transparentes los cables y poder ver y ajustar perillas con total comodidad.</li>
            </ul>
          </div>
          <div class="manual-panel-box">
            <h4>Perillas, deslizadores y pulsadores</h4>
            <ul>
              <li><strong>Perillas (knobs):</strong> Arrastre vertical continuo o rueda del ratón. Tienen diseño analógico estriado en negro mate y blanco crema.</li>
              <li><strong>Ajuste fino:</strong> Mantén pulsada la tecla <kbd>Shift</kbd> mientras arrastras para ajuste micrométrico.</li>
              <li><strong>Restablecer:</strong> Haz <strong>doble clic</strong> en cualquier perilla o deslizador para devolverlo a su valor calibrado inicial.</li>
              <li><strong>Deslizadores (Filtro-O):</strong> Arrastre horizontal para calibrar individualmente las 10 bandas de octava y la suma general.</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="man-modules" class="manual-section">
        <h3>3. Guía visual de los 14 módulos</h3>
        
        <div class="module-cards-flow">
          <div class="module-card">
            <div class="module-badge">Fila 1 · Audio y Dinámica</div>
            <h4>ENVOLVEDOR (VCA)</h4>
            <p>Amplificador controlado por voltaje. <code>Entrada 1</code> define la fuga o volumen directo constante; <code>Entrada 2</code> modula la ganancia dinámica mediante voltaje de envolvente.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 1 · Aleatoriedad</div>
            <h4>ALEATOR (Sample & Hold)</h4>
            <p>Generador aleatorio de doble salida: <code>Escalón</code> (voltajes discretos escalonados) y <code>Suave</code> (curva continua filtrada). Oscila de forma autónoma o sincronizado a reloj externo.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 1 · Efectos</div>
            <h4>MOD. ANULAR (Ring Modulator)</h4>
            <p>Multiplicador analógico de cuatro cuadrantes. Produce timbres metálicos, campanas y parciales inarmónicos combinando señales externas o su portadora interna de 220 Hz.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 1 · Fuentes</div>
            <h4>RUIDOR (Generador de Ruido)</h4>
            <p>Fuente de ruido térmico calibrado con salidas simultáneas de <strong>ruido blanco</strong> (espectro plano uniforme) y <strong>ruido rosa</strong> (−3 dB/octava, ideal para percusiones o viento).</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 1 · Acústica</div>
            <h4>REVERBERAL (Reverberador Doble)</h4>
            <p>Unidad de reverberación con 2 entradas sumadas, control de <code>intensidad</code> (mezcla seca/procesada) y <code>tiempo</code> (longitud de decaimiento espacial en sala).</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 2 · Envolventes</div>
            <h4>INTEGRADOR ENVOLV. (Generador Trapezoidal)</h4>
            <p>Generador de envolvente de 3 fases: <code>ataque</code>, <code>duración</code> (retención en pico) y <code>decaimiento</code>. El selector <code>ext./int.</code> conmuta entre disparo por pulso o bucle LFO autónomo.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 2 · Núcleo Sonoro</div>
            <h4>OSCILADOR 1 y 2 (Doble VCO)</h4>
            <p>Generadores continuos de 5 Hz a 20 kHz con salidas simultáneas Senoidal (<code>∿</code>), Triangular (<code>∧</code>), Rampa (<code>⩘</code>) y Pulso (<code>⊓</code>) con ancho de pulso variable. Incluyen FM directa o rectificada.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 2 · Filtrado</div>
            <h4>FILTRO-V (Filtro por Voltaje)</h4>
            <p>Filtro de estado variable con salidas simultáneas Pasa-Bajos (<code>baj.</code>), Pasa-Altos (<code>alt.</code>) y Pasa-Banda (<code>banda</code>), resonancia controlada por voltaje y perilla de frecuencia <code>Centro</code>.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 2 · Banco Espectral</div>
            <h4>FILTRO-O (Banco de 10 Octavas)</h4>
            <p>Banco fijo de filtros ecualizadores centrados en 25, 50, 100, 200, 400, 800, 1.6k, 3.2k, 6.5k y 13 kHz. Cada banda tiene salida directa propia y un fader de mezcla maestra <code>Suma</code>.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 3 · Reloj</div>
            <h4>PULSADOR (Reloj Maestro)</h4>
            <p>Generador de tren de pulsos (0.1 a 40 Hz) con botones metálicos de marcha/paro (<code>inicio</code> / <code>fin</code>), control de ancho de pulso y salida invertida en antifase.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Fila 3 · Programación</div>
            <h4>S E C U E N C I A D O R (Matriz de 3 × 10 Pasos)</h4>
            <p>Secuenciador analógico de 10 pasos con 3 filas de perillas. La Fila 1 está cuantizada musicalmente en semitonos; Filas 2 y 3 entregan voltajes continuos. Permite crear bucles de cualquier longitud conectando el paso deseado a <code>reinicio</code>.</p>
          </div>

          <div class="module-card">
            <div class="module-badge">Consola Inferior · Control y Salida</div>
            <h4>TECLADO y SALIDA</h4>
            <p>Teclado de 5 octavas con portamento deslizable suave y salidas de voltaje y compuerta. La etapa de salida maestra integra control de volumen, limitador suave y un osciloscopio en tiempo real estilo CRT.</p>
          </div>
        </div>
      </section>

      <section id="man-patches" class="manual-section">
        <h3>4. Banco de 8 parches de fábrica</h3>
        <div class="patches-overview-grid">
          <div class="patch-guide-item">
            <strong>1 · Fig. IV.38:</strong> La configuración histórica exacta documentada en el libro de Raúl Pavón (1981): voz dual que combina modulación anular, filtrado en banco de octavas y ruido rosa modulado por pasos.
          </div>
          <div class="patch-guide-item">
            <strong>2 · Teclado:</strong> Sintetizador sustractivo melódico listo para tocarse con teclado o MIDI, enriquecido con vibrato sutil y reverberación analógica.
          </div>
          <div class="patch-guide-item">
            <strong>3 · Bajo 8p:</strong> Secuencia de bajo analógico en 8 pasos con onda de pulso incisiva y resonancia modulada en cada paso.
          </div>
          <div class="patch-guide-item">
            <strong>4 · Campanas:</strong> Metalofonía tímbrica electroacústica en métrica de 7 pasos mediante multiplicación anular de ambos osciladores.
          </div>
          <div class="patch-guide-item">
            <strong>5 · Aleatorio:</strong> Pieza generativa autómata donde el generador trapezoidal se autodispara y modula parámetros de aleatoriedad continua.
          </div>
          <div class="patch-guide-item">
            <strong>6 · Formantes:</strong> Banco vocal sintetizado emulando vocales humanas que pueden entonarse melódicamente con el teclado.
          </div>
          <div class="patch-guide-item">
            <strong>7 · Percusión:</strong> Batería analógica secuenciada combinando transitorios contundentes de bombo y ráfagas de ruido blanco para platillos.
          </div>
          <div class="patch-guide-item">
            <strong>8 · Cosmos:</strong> Paisaje sonoro envolvente de ciencia ficción con modulaciones cruzadas de frecuencia, resonancia límite y reverberación profunda.
          </div>
        </div>
      </section>

      <section id="man-vst" class="manual-section">
        <h3>5. Plan de trabajo y versión VST</h3>
        <p>
          Existe un plan de desarrollo detallado para trasladar este motor DSP de precisión a formatos nativos de plugin de audio para estaciones de trabajo (DAWs como Ableton, Logic, Pro Tools, Reaper y FL Studio) en <strong>VST3, AU y CLAP</strong> utilizando C++ y el framework JUCE. Puedes consultar el plan técnico completo en el archivo <a href="https://github.com/laurorobles/Omnifon/blob/main/docs/ROADMAP_VST.md" target="_blank" rel="noopener noreferrer">ROADMAP_VST.md en el repositorio de GitHub</a>.
        </p>
      </section>

      <div class="modal-footer">
        <span>Omnifón Virtual desarrollado por <a href="https://www.instagram.com/laurorobles/" target="_blank" rel="noopener noreferrer">@laurorobles</a></span>
        <span>Código fuente y documentación: <a href="https://github.com/laurorobles/Omnifon" target="_blank" rel="noopener noreferrer">github.com/laurorobles/Omnifon</a></span>
      </div>
    </div>
  `}var h=e=>Object.fromEntries(e.map((e,t)=>[`s${t}`,e/24])),g=e=>Object.fromEntries(e.map((e,t)=>[`s${10+t}`,e])),_=e=>Object.fromEntries(e.map((e,t)=>[`s${20+t}`,e])),v=e=>Object.fromEntries(e.map((e,t)=>[`sw${t}`,e])),y=[{id:`fig-iv-38`,name:{es:`1 · Fig. IV.38`,en:`1 · Fig. IV.38`},description:{es:`Alambrado original del libro de Raúl Pavón (1981): ciclo de 5 pasos con modulación anular por el banco de octavas + ruido rosa con filtrado programado.`,en:`Raúl Pavón’s original 1981 book patch (Fig. IV.38): 5-step ring-modulated sequence through the octave bank + programmed bandpass pink noise.`},cables:[[`pulsador.pulsos`,`integrador.pulso`],[`pulsador.pulsos2`,`secuenciador.pulso`],[`pulsador.inv`,`aleator.pulso`],[`secuenciador.st5`,`secuenciador.reinicio`],[`secuenciador.a`,`osc1.frec`],[`aleator.esc`,`osc1.mod`],[`osc1.tri`,`envolvedor.entrada`],[`integrador.sal`,`envolvedor.control`],[`osc1.rampa`,`anillo.b`],[`osc2.sen`,`anillo.a`],[`anillo.sal`,`filtroo.entrada`],[`filtroo.suma`,`reverberal.e2`],[`ruidor.rosa`,`filtrov.entrada`],[`secuenciador.b`,`filtrov.mod`],[`filtrov.banda`,`reverberal.e1`],[`envolvedor.s1`,`salida.izq`],[`reverberal.sal`,`salida.der`]],values:{pulsador:{reloj:4.5,ancho:.35},secuenciador:{...h([0,7,10,3,12,5,15,7,2,10]),...g([.15,.75,.35,.85,.25,.65,.9,.4,.55,.3]),...v([1,1,1,1,1,1,1,1,1,1])},osc1:{frecuencia:196,modulador:.12,ancho:.5,modoMod:0},osc2:{frecuencia:293.66,modulador:0},anillo:{nivel:.75},integrador:{ataque:.008,modo:0,duracion:.06,decaimiento:.18},envolvedor:{nivel:0,mod:.9},filtrov:{centro:520,corte:0,ancho:.28,modulacion:2.2},filtroo:{corte:.85,g0:.72,g1:.48,g2:.75,g3:.42,g4:.74,g5:.64,g6:.46,g7:.5,g8:.35,g9:.3,suma:.68},reverberal:{intensidad:.42,tiempo:.68},salida:{volumen:.62}}},{id:`teclado`,name:{es:`2 · Teclado`,en:`2 · Keyboard`},description:{es:`Voz solista sustractiva (1960–64) con vibrato sutil y filtro resonante: toca el teclado de 5 octavas, las teclas A–Ñ o un controlador MIDI.`,en:`Expressive 1960s subtractive lead with subtle vibrato and resonant filter: play the 5-octave keyboard, keys A–;, or MIDI.`},cables:[[`teclado.volt`,`osc1.frec`],[`osc2.sen`,`osc1.mod`],[`osc1.rampa`,`filtrov.entrada`],[`teclado.pulso`,`integrador.pulso`],[`integrador.sal`,`filtrov.mod`],[`filtrov.bajos`,`envolvedor.entrada`],[`integrador.sal2`,`envolvedor.control`],[`envolvedor.s1`,`salida.izq`],[`envolvedor.s2`,`reverberal.e1`],[`reverberal.sal`,`salida.der`]],values:{osc1:{frecuencia:261.63,modulador:.02,fino:0},osc2:{frecuencia:5.4,modulador:0},filtrov:{centro:420,corte:0,ancho:.26,modulacion:3.1},integrador:{ataque:.006,modo:0,duracion:.12,decaimiento:.42},envolvedor:{nivel:0,mod:.92},reverberal:{intensidad:.32,tiempo:.62},teclado:{portamento:.03},salida:{volumen:.65}}},{id:`bajo`,name:{es:`3 · Bajo 8p`,en:`3 · 8-Step Bass`},description:{es:`Secuencia rítmica de bajo en 8 pasos (puente al paso 9) con onda rectangular, resonancia modulada por paso y envolvente punzante.`,en:`Driving 8-step analog bassline (step-9 reset jumper) with pulse wave, per-step resonance modulation, and punchy envelope.`},cables:[[`pulsador.pulsos`,`secuenciador.pulso`],[`secuenciador.st8`,`secuenciador.reinicio`],[`secuenciador.a`,`osc1.frec`],[`secuenciador.pulsoSal`,`integrador.pulso`],[`osc1.cuad`,`filtrov.entrada`],[`integrador.sal`,`filtrov.mod`],[`secuenciador.b`,`filtrov.anchoCv`],[`filtrov.bajos`,`envolvedor.entrada`],[`integrador.sal2`,`envolvedor.control`],[`envolvedor.s1`,`salida.izq`],[`envolvedor.s2`,`reverberal.e1`],[`reverberal.sal`,`salida.der`]],values:{osc1:{frecuencia:65.41,ancho:.28,modulador:0},pulsador:{reloj:7.2,ancho:.42},secuenciador:{...h([0,0,12,0,7,10,0,15,0,12]),...g([.1,.5,.05,.6,.15,.08,.55,.05,.3,.3]),...v([1,1,1,1,1,1,1,1,1,1])},filtrov:{centro:210,corte:0,ancho:.16,modulacion:3.4},integrador:{ataque:.005,modo:0,duracion:.03,decaimiento:.13},envolvedor:{nivel:0,mod:.95},reverberal:{intensidad:.22,tiempo:.45},salida:{volumen:.68}}},{id:`campanas`,name:{es:`4 · Campanas`,en:`4 · Ring Bells`},description:{es:`Timbres metálicos e inarmónicos estilo estudio de Colonia: modulación anular en compás de 7 pasos esculpida por el banco Filtro-O.`,en:`Cologne-studio metallic timbres: 7-step inharmonic ring modulation sculpted through the 10-octave filter bank.`},cables:[[`pulsador.pulsos`,`secuenciador.pulso`],[`secuenciador.st7`,`secuenciador.reinicio`],[`secuenciador.a`,`osc1.frec`],[`secuenciador.b`,`osc2.frec`],[`osc1.sen`,`anillo.a`],[`osc2.tri`,`anillo.b`],[`secuenciador.c`,`anillo.mod`],[`anillo.sal`,`envolvedor.entrada`],[`secuenciador.pulsoSal`,`integrador.pulso`],[`integrador.sal`,`envolvedor.control`],[`envolvedor.s1`,`filtroo.entrada`],[`filtroo.suma`,`reverberal.e1`],[`envolvedor.s2`,`salida.izq`],[`reverberal.sal`,`salida.der`]],values:{pulsador:{reloj:3.2,ancho:.25},secuenciador:{...h([0,5,11,14,7,18,3,0,0,0]),...g([.1,.62,.34,.81,.47,.22,.73,.5,.5,.5]),..._([.4,.8,.3,.9,.5,.7,.6,.5,.5,.5]),...v([1,1,1,0,1,1,1,1,1,1])},osc1:{frecuencia:310,modulador:0},osc2:{frecuencia:447,modulador:0},anillo:{nivel:.9},integrador:{ataque:.005,modo:0,duracion:.02,decaimiento:.55},envolvedor:{nivel:0,mod:.95},filtroo:{corte:.95,g0:.1,g1:.15,g2:.3,g3:.55,g4:.8,g5:.9,g6:.85,g7:.95,g8:.75,g9:.6,suma:.85},reverberal:{intensidad:.58,tiempo:.82},salida:{volumen:.66}}},{id:`aleatorio`,name:{es:`5 · Aleatorio`,en:`5 · Aleatoric`},description:{es:`Estudio generativo años 60: el Integrador en modo interno (int.) autocicla y dispara al Aleator para crear melodías y timbres FM impredecibles.`,en:`1960s generative lab: the Integrator self-cycles in internal (int.) mode, clocking the Randomizer for unpredictable FM gestures.`},cables:[[`integrador.pulsoSal`,`aleator.pulso`],[`aleator.esc`,`osc1.frec`],[`osc2.sen`,`osc1.mod`],[`aleator.suave`,`osc2.frec`],[`osc1.rampa`,`filtrov.entrada`],[`integrador.sal`,`filtrov.mod`],[`filtrov.bajos`,`envolvedor.entrada`],[`integrador.sal2`,`envolvedor.control`],[`envolvedor.s1`,`reverberal.e1`],[`filtrov.altos`,`reverberal.e2`],[`envolvedor.s2`,`salida.izq`],[`reverberal.sal`,`salida.der`]],values:{integrador:{ataque:.015,modo:1,duracion:.05,decaimiento:.22},osc1:{frecuencia:280,modulador:.35,modoMod:1},osc2:{frecuencia:190,modulador:0},filtrov:{centro:620,corte:0,ancho:.2,modulacion:2.8},envolvedor:{nivel:0,mod:.88},reverberal:{intensidad:.48,tiempo:.74},salida:{volumen:.6}}},{id:`formantes`,name:{es:`6 · Formantes`,en:`6 · Formants`},description:{es:`Canto espectral: armónicos de rampa y aire de ruido rosa esculpidos como formantes vocales en el Filtro-O (también responde al teclado).`,en:`Spectral choir: sawtooth harmonics and pink-noise breath sculpted into vowel formants on the O-Filter (also playable on the keyboard).`},cables:[[`teclado.volt`,`osc1.frec`],[`osc2.sen`,`osc1.mod`],[`osc1.rampa`,`filtroo.entrada`],[`filtroo.suma`,`envolvedor.entrada`],[`teclado.pulso`,`integrador.pulso`],[`integrador.sal`,`envolvedor.control`],[`ruidor.rosa`,`filtrov.entrada`],[`aleator.suave`,`filtrov.control`],[`envolvedor.s1`,`reverberal.e1`],[`filtrov.banda`,`reverberal.e2`],[`envolvedor.s2`,`salida.izq`],[`reverberal.sal`,`salida.der`]],values:{osc1:{frecuencia:146.83,modulador:.025,fino:0},osc2:{frecuencia:5.8,modulador:0},integrador:{ataque:.25,modo:0,duracion:.2,decaimiento:.9},envolvedor:{nivel:.45,mod:.55},filtroo:{corte:.9,g0:.15,g1:.2,g2:.35,g3:.2,g4:.95,g5:.85,g6:.15,g7:.9,g8:.3,g9:.1,suma:.9},filtrov:{centro:1100,corte:0,ancho:.22,modulacion:1.5},reverberal:{intensidad:.62,tiempo:.85},teclado:{portamento:.08},salida:{volumen:.64}}},{id:`percusion`,name:{es:`7 · Percusión`,en:`7 · Percussion`},description:{es:`Polirritmia analógica de 10 pasos: bombos de barrido exponencial y ráfagas metálicas de ruido blanco con pasos alternados en los switches inferiores.`,en:`10-step analog drum lab: pitch-swept kicks and metallic white-noise bursts shaped by the bottom step switches.`},cables:[[`pulsador.pulsos`,`secuenciador.pulso`],[`secuenciador.pulsoSal`,`integrador.pulso`],[`integrador.sal`,`osc1.mod`],[`secuenciador.a`,`osc1.frec`],[`osc1.sen`,`envolvedor.entrada`],[`integrador.sal2`,`envolvedor.control`],[`ruidor.blanco`,`filtrov.entrada`],[`secuenciador.b`,`filtrov.control`],[`filtrov.altos`,`anillo.a`],[`secuenciador.c`,`anillo.b`],[`anillo.sal`,`reverberal.e2`],[`envolvedor.s1`,`salida.izq`],[`envolvedor.s2`,`reverberal.e1`],[`reverberal.sal`,`salida.der`]],values:{pulsador:{reloj:6.8,ancho:.3},secuenciador:{...h([0,7,0,12,0,3,15,0,5,10]),...g([.1,.9,.3,.85,.2,.95,.4,.75,.2,.9]),..._([.8,.3,.2,.9,.1,.7,.4,.85,.2,.95]),...v([1,0,1,1,0,1,1,0,1,1])},osc1:{frecuencia:55,modulador:.65,modoMod:0},integrador:{ataque:.005,modo:0,duracion:.015,decaimiento:.11},envolvedor:{nivel:0,mod:.95},filtrov:{centro:2400,corte:.5,ancho:.25,modulacion:1.5},anillo:{nivel:.65},reverberal:{intensidad:.28,tiempo:.5},salida:{volumen:.68}}},{id:`cosmos`,name:{es:`8 · Cosmos`,en:`8 · Deep Cosmos`},description:{es:`Paisaje electroacústico contemplativo: oleadas lentas autocicladas, modulación anular subaudible y viento estelar sobre el banco de octavas.`,en:`Contemplative electroacoustic soundscape: slow self-cycling waves, sub-audio ring modulation, and stellar pink noise.`},cables:[[`osc2.sen`,`osc1.mod`],[`aleator.suave`,`osc1.frec`],[`osc1.sen`,`anillo.a`],[`anillo.sal`,`envolvedor.entrada`],[`integrador.sal`,`envolvedor.control`],[`envolvedor.s1`,`reverberal.e1`],[`ruidor.rosa`,`filtroo.entrada`],[`filtroo.suma`,`filtrov.entrada`],[`integrador.sal2`,`filtrov.mod`],[`filtrov.bajos`,`reverberal.e2`],[`reverberal.sal`,`salida.izq`],[`reverberal.sal2`,`salida.der`]],values:{integrador:{ataque:1.6,modo:1,duracion:.8,decaimiento:2.2},osc1:{frecuencia:220,modulador:.28,modoMod:0},osc2:{frecuencia:5.1,modulador:0},anillo:{nivel:.72},envolvedor:{nivel:.12,mod:.75},filtroo:{corte:.78,g0:.3,g1:.5,g2:.2,g3:.7,g4:.1,g5:.8,g6:.2,g7:.65,g8:.15,g9:.35,suma:.8},filtrov:{centro:340,corte:0,ancho:.22,modulacion:2.6},reverberal:{intensidad:.72,tiempo:.92},salida:{volumen:.6}}},{id:`prototipo-60s`,name:{es:`9 · Prototipo 60s`,en:`9 · 60s Prototype`},description:{es:`Evocación del prototipo original (c. 1960–64): un solo oscilador continuo (10 Hz–20 kHz), filtro por voltaje, envolvente trapezoidal y salida directa seca sin reverberación.`,en:`Evocation of the original 1960–64 prototype: single continuous oscillator (10 Hz–20 kHz), voltage-controlled filter, trapezoid envelope, and dry direct output with no reverb.`},cables:[[`teclado.volt`,`osc1.frec`],[`teclado.pulso`,`integrador.pulso`],[`osc1.cuad`,`filtrov.entrada`],[`integrador.sal`,`filtrov.mod`],[`filtrov.bajos`,`envolvedor.entrada`],[`integrador.sal2`,`envolvedor.control`],[`envolvedor.s1`,`salida.izq`]],values:{osc1:{frecuencia:261.63,modulador:0,fino:0,ancho:.48},filtrov:{centro:380,corte:0,ancho:.34,modulacion:2.8},integrador:{ataque:.012,modo:0,duracion:.08,decaimiento:.32},envolvedor:{nivel:0,mod:.94},teclado:{portamento:.015},salida:{volumen:.68}}}],ee=e=>e.cables.map(([e,t])=>({from:e,to:t})),te=new URL(`processors-D0YRup0o.js`,import.meta.url).href;function ne(e){let t=e.indexOf(`.`);return[e.slice(0,t),e.slice(t+1)]}function b(e,t){let[n,r]=ne(e),i=c.find(e=>e.id===n);if(!i)throw Error(`Módulo desconocido: ${n}`);let a=s[i.type],o=(t===`in`?a.inputs:a.outputs).findIndex(e=>e.id===r);if(o<0)throw Error(`Conector desconocido: ${e}`);return[n,o]}function re(e){if(e.to===`secuenciador.reinicio`&&e.from.startsWith(`secuenciador.st`)){let t=Number(e.from.slice(15));return Number.isFinite(t)?t:null}return null}var ie=class{ctx=null;analyser=null;nodes=new Map;listeners=new Map;get running(){return this.ctx?.state===`running`}async start(e,t){if(this.ctx){await this.ctx.resume();return}let n=new AudioContext({latencyHint:`interactive`});await n.audioWorklet.addModule(te);for(let t of c){let r=s[t.type],i=new AudioWorkletNode(n,r.type,{numberOfInputs:r.inputs.length,numberOfOutputs:r.stereo?1:r.outputs.length,outputChannelCount:r.stereo?[2]:r.outputs.map(()=>1),channelCount:1,channelCountMode:`explicit`,channelInterpretation:`discrete`,parameterData:e[t.id]??{}});i.port.onmessage=e=>this.listeners.get(t.id)?.forEach(t=>t(e.data)),this.nodes.set(t.id,i)}let r=n.createAnalyser();r.fftSize=4096,this.nodes.get(`salida`).connect(r),r.connect(n.destination),this.ctx=n,this.analyser=r,t.forEach(e=>this.connect(e))}connect(e){if(!this.ctx)return;let t=re(e);if(t!==null){this.send(`secuenciador`,{type:`resetAt`,step:t});return}let[n,r]=b(e.from,`out`),[i,a]=b(e.to,`in`);this.nodes.get(n).connect(this.nodes.get(i),r,a)}disconnect(e){if(!this.ctx)return;if(re(e)!==null){this.send(`secuenciador`,{type:`resetAt`,step:null});return}let[t,n]=b(e.from,`out`),[r,i]=b(e.to,`in`);try{this.nodes.get(t).disconnect(this.nodes.get(r),n,i)}catch{}}set(e,t,n){let r=this.nodes.get(e);r&&this.ctx&&r.parameters.get(t)?.setValueAtTime(n,this.ctx.currentTime)}send(e,t){this.nodes.get(e)?.port.postMessage(t)}on(e,t){let n=this.listeners.get(e)??[];n.push(t),this.listeners.set(e,n)}},x=`http://www.w3.org/2000/svg`,ae=[`#a7a6a0`,`#8e8d87`,`#b9b7ae`,`#7f7e78`,`#9d9b92`],oe=class{host;h;cables=[];svg;gCables;temp;drag=null;constructor(e,t){this.host=e,this.h=t,this.svg=document.createElementNS(x,`svg`),this.svg.classList.add(`cables`),this.gCables=document.createElementNS(x,`g`),this.temp=document.createElementNS(x,`g`),this.svg.append(this.gCables,this.temp),e.appendChild(this.svg),new ResizeObserver(()=>this.render()).observe(e),window.addEventListener(`resize`,()=>this.render()),e.addEventListener(`pointerdown`,e=>this.down(e)),e.addEventListener(`pointermove`,e=>this.move(e)),e.addEventListener(`pointerup`,e=>this.up(e)),e.addEventListener(`pointercancel`,()=>this.cancel())}set(e){this.cables=e.map(e=>({...e})),this.render()}jackEl(e){return this.host.querySelector(`.jack[data-jack="${CSS.escape(e)}"]`)}center(e){let t=this.jackEl(e);if(!t)return null;let n=t.getBoundingClientRect(),r=this.svg.getBoundingClientRect();return[n.left+n.width/2-r.left,n.top+n.height/2-r.top]}local(e){let t=this.svg.getBoundingClientRect();return[e.clientX-t.left,e.clientY-t.top]}path(e,t){let n=Math.hypot(t[0]-e[0],t[1]-e[1]),r=Math.min(180,25+n*.32);return`M${e[0]},${e[1]} C${e[0]},${e[1]+r} ${t[0]},${t[1]+r} ${t[0]},${t[1]}`}drawCable(e,t,n,r){let i=this.path(t,n),a=document.createElementNS(x,`path`);a.setAttribute(`d`,i),a.setAttribute(`class`,`cable-shadow`);let o=document.createElementNS(x,`path`);o.setAttribute(`d`,i),o.setAttribute(`class`,`cable-outline`);let s=document.createElementNS(x,`path`);s.setAttribute(`d`,i),s.setAttribute(`class`,`cable-body`),s.setAttribute(`stroke`,r);let c=document.createElementNS(x,`path`);c.setAttribute(`d`,i),c.setAttribute(`class`,`cable-shine`),e.append(a,o,s,c);for(let r of[t,n]){let t=document.createElementNS(x,`circle`);t.setAttribute(`cx`,String(r[0])),t.setAttribute(`cy`,String(r[1])),t.setAttribute(`r`,`6.5`),t.setAttribute(`class`,`plug`),e.appendChild(t)}}render(){let{width:e,height:t}=this.host.getBoundingClientRect();this.svg.setAttribute(`viewBox`,`0 0 ${e} ${t}`),this.gCables.replaceChildren(),this.host.querySelectorAll(`.jack.patched`).forEach(e=>e.classList.remove(`patched`)),this.cables.forEach((e,t)=>{let n=this.center(e.from),r=this.center(e.to);n&&r&&(this.jackEl(e.from)?.classList.add(`patched`),this.jackEl(e.to)?.classList.add(`patched`),this.drawCable(this.gCables,n,r,ae[t%ae.length]))})}down(e){let t=e.target.closest(`.jack`);if(!t)return;e.preventDefault();let n=t.dataset.jack;if(t.dataset.dir===`in`){let e=this.cables.find(e=>e.to===n);e?(this.remove(e),this.drag={fixed:e.from,dir:`out`,x:0,y:0}):this.drag={fixed:n,dir:`in`,x:0,y:0}}else this.drag={fixed:n,dir:`out`,x:0,y:0};this.host.setPointerCapture(e.pointerId),this.host.classList.add(`patching`),this.move(e)}move(e){if(!this.drag)return;let t=this.center(this.drag.fixed);t&&(this.temp.replaceChildren(),this.drawCable(this.temp,t,this.local(e),`#c8c6bd`))}up(e){if(!this.drag)return;let t=document.elementFromPoint(e.clientX,e.clientY)?.closest(`.jack`);if(t&&t.dataset.dir!==this.drag.dir){let e=t.dataset.jack,n=this.drag.dir===`out`?{from:this.drag.fixed,to:e}:{from:e,to:this.drag.fixed},r=this.cables.find(e=>e.to===n.to);r&&this.remove(r),this.cables.push(n),this.h.onConnect(n)}this.cancel(),this.render()}cancel(){this.drag=null,this.temp.replaceChildren(),this.host.classList.remove(`patching`)}remove(e){this.cables=this.cables.filter(t=>t!==e),this.h.onDisconnect(e),this.render()}},S=`es`;function se(e){S=e}function C(e,t){switch(e.fmt){case`hz`:return t>=1e3?`${(t/1e3).toFixed(t>=1e4?1:2)} kHz`:`${t.toFixed(t<10?2:+(t<100))} Hz`;case`s`:return t<1?`${(t*1e3).toFixed(+(t<.01))} ms`:`${t.toFixed(2)} s`;case`pct`:return`${Math.round(t*100)} %`;case`oct`:return`${t>0?`+`:``}${t.toFixed(2)} oct`;case`st`:return`${t>0?`+`:``}${t.toFixed(2)} st`;case`int`:return String(Math.round(t));case`choice`:return d(e.choices?.[Math.round(t)]??String(t),S)}}function w(e,t){return e.curve===`log`?Math.log(t/e.min)/Math.log(e.max/e.min):(t-e.min)/(e.max-e.min)}function T(e,t){t=Math.min(1,Math.max(0,t));let n=e.curve===`log`?e.min*(e.max/e.min)**t:e.min+t*(e.max-e.min);return e.fmt===`int`&&(n=Math.round(n)),n}function E(e,t,n,r,i,a){e.tabIndex=0,e.setAttribute(`role`,`slider`),e.setAttribute(`aria-label`,t.label);let o=0,s=0;e.addEventListener(`pointerdown`,t=>{t.stopPropagation(),e.setPointerCapture(t.pointerId),o=i===`y`?t.clientY:t.clientX,s=n(),e.classList.add(`active`)}),e.addEventListener(`pointermove`,t=>{if(!e.hasPointerCapture(t.pointerId))return;let n=i===`y`?o-t.clientY:t.clientX-o;r(s+n/(t.shiftKey?a*6:a))});let c=t=>{e.hasPointerCapture(t.pointerId)&&e.releasePointerCapture(t.pointerId),e.classList.remove(`active`)};e.addEventListener(`pointerup`,c),e.addEventListener(`pointercancel`,c),e.addEventListener(`dblclick`,()=>r(w(t,t.def))),e.addEventListener(`wheel`,e=>{e.preventDefault(),r(n()-Math.sign(e.deltaY)*(e.shiftKey?.002:.02))},{passive:!1}),e.addEventListener(`keydown`,e=>{let t=e.shiftKey?.002:.02;if(e.key===`ArrowUp`||e.key===`ArrowRight`)r(n()+t);else if(e.key===`ArrowDown`||e.key===`ArrowLeft`)r(n()-t);else return;e.preventDefault(),e.stopPropagation()})}var ce=(()=>{let e=[];for(let t=0;t<=10;t++){let n=(-135+t*27-90)*Math.PI/180,r=50+Math.cos(n)*42.2,i=50+Math.sin(n)*42.2,a=50+Math.cos(n)*47.2,o=50+Math.sin(n)*47.2;e.push(`<line x1="${r.toFixed(2)}" y1="${i.toFixed(2)}" x2="${a.toFixed(2)}" y2="${o.toFixed(2)}" class="knob-tick" />`)}return e.join(``)})(),le=(()=>{let e=[];for(let t=0;t<32;t++){let n=(t*360/32-90)*Math.PI/180,r=50+Math.cos(n)*26.2,i=50+Math.sin(n)*26.2,a=50+Math.cos(n)*33.6,o=50+Math.sin(n)*33.6;e.push(`<line x1="${r.toFixed(2)}" y1="${i.toFixed(2)}" x2="${a.toFixed(2)}" y2="${o.toFixed(2)}" class="knob-rib" />`)}return e.join(``)})();function ue(e=!1){return`
    <svg class="knob-svg" viewBox="${e?`12 12 76 76`:`0 0 100 100`}" aria-hidden="true">
      ${e?``:`<circle cx="50" cy="50" r="41.8" class="knob-well" />${ce}`}
      <g class="knob-shadow">
        <g class="knob-rotor">
          <circle cx="50" cy="50" r="34" class="knob-skirt" />
          ${le}
          <circle cx="50" cy="50" r="34" class="knob-rim" />
          <circle cx="50" cy="50" r="26.2" class="knob-face" />
          <rect x="47.8" y="18.6" width="4.4" height="29" rx="2.2" class="knob-pointer-svg" />
        </g>
      </g>
    </svg>`}function D(e,t,n,r={}){let{size:i=`md`,white:a=!1,showLabel:o=!0,labelBelow:s=!1,noTicks:c=!1}=r,l=document.createElement(`div`);l.className=`knob knob-${i} ${a?`knob-white`:`knob-dark`}${c?` knob-noticks`:``}`;let[u,f]=e.ticks??[``,``],p=!c&&(u||f)?`<div class="knob-minmax"><span data-i18n="${u}">${u}</span><span data-i18n="${f}">${f}</span></div>`:``,m=o?`<div class="knob-label" data-i18n="${e.label}">${e.label}</div>`:``;l.innerHTML=s?`<div class="knob-body">${ue(c)}</div>${p}${m}<output class="knob-value"></output>`:`${m}<div class="knob-body">${ue(c)}</div>${p}<output class="knob-value"></output>`;let h=l.querySelector(`.knob-rotor`),g=l.querySelector(`.knob-value`),_=w(e,t),v=()=>{let t=-135+_*270;h.setAttribute(`transform`,`rotate(${t.toFixed(2)} 50 50)`),g.textContent=C(e,T(e,_));let n=d(e.label,S);l.setAttribute(`aria-label`,n),l.setAttribute(`aria-valuetext`,g.textContent),l.title=`${n}: ${g.textContent}`};return E(l,e,()=>_,t=>{_=Math.min(1,Math.max(0,t)),v(),n(T(e,_))},`y`,200),v(),{el:l,set:t=>{_=w(e,t),v()},refreshLang:v}}function de(e,t,n){let r=document.createElement(`div`);r.className=`fader`,r.innerHTML=`<div class="fader-track"></div><div class="fader-cap"></div>`;let i=r.querySelector(`.fader-cap`),a=w(e,t),o=()=>{i.style.left=`${a*100}%`;let t=C(e,T(e,a)),n=d(e.label,S);r.title=`${n}: ${t}`,r.setAttribute(`aria-label`,n),r.setAttribute(`aria-valuetext`,t)};return E(r,e,()=>a,t=>{a=Math.min(1,Math.max(0,t)),o(),n(T(e,a))},`x`,80),o(),{el:r,set:t=>{a=w(e,t),o()},refreshLang:o}}function fe(e,t,n){let r=document.createElement(`div`);r.className=`fader-v`,r.innerHTML=`<div class="fader-v-track"></div><div class="fader-v-cap"></div>`;let i=r.querySelector(`.fader-v-cap`),a=w(e,t),o=()=>{i.style.bottom=`${a*100}%`;let t=C(e,T(e,a)),n=d(e.label,S);r.title=`${n}: ${t}`,r.setAttribute(`aria-label`,n),r.setAttribute(`aria-valuetext`,t)};return E(r,e,()=>a,t=>{a=Math.min(1,Math.max(0,t)),o(),n(T(e,a))},`y`,80),o(),{el:r,set:t=>{a=w(e,t),o()},refreshLang:o}}function pe(e,t,n){let r=document.createElement(`div`);r.className=`slide-sw`;let[i,a]=e.choices??[`0`,`1`];r.innerHTML=`
    <span class="slide-lbl" data-i18n="${i}">${i}</span>
    <button type="button" class="slide-slot" aria-label="${e.label}"><span class="slide-knob"></span></button>
    <span class="slide-lbl" data-i18n="${a}">${a}</span>`;let o=r.querySelector(`button`),s=Math.round(t),c=t=>{s=+!!Math.round(t),o.classList.toggle(`alt`,s===1),o.title=`${d(e.label,S)}: ${d(s?a:i,S)}`};return o.addEventListener(`click`,()=>{let e=+!s;c(e),n(e)}),c(t),{el:r,set:c,refreshLang:()=>c(s)}}function me(e,t,n){let r=document.createElement(`button`);r.type=`button`,r.className=`step-sw`,r.innerHTML=`<span class="step-sw-lever"></span>`;let i=Math.round(t),a=t=>{i=+!!Math.round(t),r.classList.toggle(`on`,i===1),r.title=`${d(e.label,S)}: ${i?`ON`:`OFF`}`};return r.addEventListener(`click`,()=>{let e=+!i;a(e),n(e)}),a(t),{el:r,set:a,refreshLang:()=>a(i)}}var he=[`C`,`C♯`,`D`,`D♯`,`E`,`F`,`F♯`,`G`,`G♯`,`A`,`A♯`,`B`],ge=new Set([1,3,6,8,10]),_e={a:0,w:1,s:2,e:3,d:4,f:5,t:6,g:7,y:8,h:9,u:10,j:11,k:12,o:13,l:14,p:15,ñ:16,";":16};function ve(e,t,n=24,r=84){let i=new Map,a=[];for(let e=n;e<=r;e++)ge.has(e%12)||a.push(e);let o=100/a.length,s=0;for(let t=n;t<=r;t++){let n=document.createElement(`div`),r=ge.has(t%12);n.className=r?`key black`:`key white`,n.dataset.note=String(t),n.title=`${he[t%12]}${Math.floor(t/12)-1}`,r?(n.style.left=`${s*o-o*.32}%`,n.style.width=`${o*.64}%`):(n.style.left=`${s*o}%`,n.style.width=`${o}%`,t%12==0&&(n.innerHTML=`<span>C${Math.floor(t/12)-1}</span>`),s++),e.appendChild(n),i.set(t,n)}let c=new Set,l=e=>{c.has(e)||(c.add(e),i.get(e)?.classList.add(`down`),t.noteOn(e))},u=e=>{c.has(e)&&(c.delete(e),i.get(e)?.classList.remove(`down`),t.noteOff(e))},d=null,f=(e,t)=>{let n=document.elementFromPoint(e,t)?.closest(`.key`)?.dataset.note;return n===void 0?null:Number(n)};e.addEventListener(`pointerdown`,t=>{e.setPointerCapture(t.pointerId),d=f(t.clientX,t.clientY),d!==null&&l(d)}),e.addEventListener(`pointermove`,e=>{if(d===null)return;let t=f(e.clientX,e.clientY);t!==null&&t!==d&&(u(d),d=t,l(t))});let p=()=>{d!==null&&u(d),d=null};e.addEventListener(`pointerup`,p),e.addEventListener(`pointercancel`,p);let m=48,h=document.getElementById(`octave-label`),g=()=>{h&&(h.textContent=`C${m/12-1}`)};g();let _=new Map;return window.addEventListener(`keydown`,e=>{if(e.repeat||e.metaKey||e.ctrlKey||e.altKey||e.target.tagName===`INPUT`)return;let t=e.key.toLowerCase();if(t===`z`||t===`x`){m=Math.min(72,Math.max(24,m+(t===`z`?-12:12))),g();return}let n=_e[t];if(n===void 0)return;let r=m+n;_.set(t,r),l(r)}),window.addEventListener(`keyup`,e=>{let t=e.key.toLowerCase(),n=_.get(t);n!==void 0&&(_.delete(t),u(n))}),window.addEventListener(`blur`,()=>{[...c].forEach(u),_.clear()}),{press:l,release:u}}var O=(e,t=``,n=``)=>{let r=document.createElement(e);return t&&(r.className=t),n&&(r.innerHTML=n),r},k=(e,t,n)=>{let r=O(e,t,n);return r.dataset.i18n=n,r};function ye(e,t,n){let r=O(`div`,`jack`);return r.dataset.jack=`${e}.${t.id}`,r.dataset.dir=n,r.dataset.jackLabel=t.label,r.title=`${t.label} (${n===`in`?`entrada`:`salida`})`,r}function A(e,t,n){let r=s[e.type],i=(t===`in`?r.inputs:r.outputs).find(e=>e.id===n);return ye(e.id,i,t)}function j(e,t,n,r={}){let i=s[e.type].params.find(e=>e.id===t),a=n.values[e.id]?.[i.id]??i.def,o=t=>n.onParam(e.id,i.id,t),c;switch(i.control){case`fader`:c=de(i,a,o);break;case`fader-v`:c=fe(i,a,o);break;case`slide-sw`:c=pe(i,a,o);break;case`step-sw`:c=me(i,a,o);break;case`knob-white`:c=D(i,a,o,{size:r.sizeOverride??`lg`,white:!0,showLabel:r.showLabel??!0,labelBelow:r.labelBelow??!1});break;case`knob-white-sm`:c=D(i,a,o,{size:r.sizeOverride??`md`,white:!0,showLabel:r.showLabel??!0,labelBelow:r.labelBelow??!1});break;case`knob-sm`:c=D(i,a,o,{size:`sm`,white:!1,showLabel:r.showLabel??!1,labelBelow:r.labelBelow??!1,noTicks:r.noTicks??!0});break;default:c=D(i,a,o,{size:r.sizeOverride??`md`,white:!1,showLabel:r.showLabel??!0,labelBelow:r.labelBelow??!1})}return n.setters[`${e.id}.${i.id}`]=c.set,c.refreshLang&&n.langHooks.push(c.refreshLang),c.el}function M(e){let t=O(`div`,`v-bus`);return e.forEach((e,n)=>{n>0&&t.appendChild(O(`span`,`v-line`)),t.appendChild(e)}),t}function N(e,t,n=``){let r=O(`div`,`linked-row ${n}`.trim());return r.append(e,O(`span`,`h-line`),t),r}function P(e,t,n,r,i){let a=O(`button`,`metal-btn`);a.type=`button`,a.title=n,i&&(a.dataset.lamp=i),a.addEventListener(`pointerdown`,n=>{n.stopPropagation(),a.setPointerCapture(n.pointerId),a.classList.add(`down`),r.onTrigger(e,t,!0)});let o=()=>{a.classList.contains(`down`)&&(a.classList.remove(`down`),r.onTrigger(e,t,!1))};return a.addEventListener(`pointerup`,o),a.addEventListener(`pointercancel`,o),a}function F(e,t=``){let n=s[e.type],r=O(`section`,`panel mod-${e.type} ${t}`.trim());r.style.gridArea=e.area,r.dataset.module=e.id;let i=k(`h3`,``,n.title);return r.append(O(`span`,`screw tl`),O(`span`,`screw tr`),O(`span`,`screw bl`),O(`span`,`screw br`),i),r}var I=()=>O(`div`,`maker`,`OMNIFÓN`);function L(e,t){let n=O(`div`,`subheaders`);return n.appendChild(e?k(`span`,`io-title`,e):O(`span`)),n.appendChild(t?k(`span`,`io-title`,t):O(`span`)),n}function be(e,t){let n=F(e);n.appendChild(L(`Entradas`,`Salidas`));let r=O(`div`,`mod-body env-body`),i=O(`div`,`env-left`);i.appendChild(N(A(e,`in`,`entrada`),j(e,`nivel`,t,{showLabel:!1}),`r1`)),i.appendChild(N(A(e,`in`,`control`),j(e,`mod`,t,{showLabel:!1}),`r2`));let a=O(`div`,`env-right`);return a.appendChild(M([A(e,`out`,`s1`),A(e,`out`,`s2`)])),r.append(i,a),n.append(r,I()),n}function xe(e){let t=F(e);t.appendChild(L(`Entrada`,`Salidas`));let n=O(`div`,`mod-body ale-body`),r=O(`div`,`ale-in`);r.appendChild(A(e,`in`,`pulso`));let i=O(`div`,`ale-out`);return i.appendChild(M([A(e,`out`,`esc`),A(e,`out`,`suave`)])),n.append(r,i),t.append(n,I()),t}function Se(e,t){let n=F(e);n.appendChild(L(`Entradas`,`Salidas`));let r=O(`div`,`mod-body ani-body`),i=O(`div`,`ani-left`);i.appendChild(A(e,`in`,`a`)),i.appendChild(N(A(e,`in`,`b`),j(e,`nivel`,t,{showLabel:!1}),`long`)),i.appendChild(A(e,`in`,`mod`));let a=O(`div`,`ani-right`);return a.appendChild(M([A(e,`out`,`sal`),A(e,`out`,`sal2`)])),r.append(i,a),n.append(r,I()),n}function Ce(e){let t=F(e);t.appendChild(L(void 0,`Salidas`));let n=O(`div`,`mod-body rui-body`),r=O(`div`,`rui-row`);r.append(k(`span`,`mini-lbl`,`blanco`),M([A(e,`out`,`blanco`),O(`span`,`pin-dot`)]));let i=O(`div`,`rui-row`);return i.append(k(`span`,`mini-lbl`,`rosa`),M([A(e,`out`,`rosa`),O(`span`,`pin-dot`)])),n.append(r,i),t.append(n,I()),t}function we(e,t){let n=F(e);n.appendChild(L(`Entradas`,`Salidas`));let r=O(`div`,`mod-body rev-body`),i=O(`div`,`rev-left`);i.appendChild(N(A(e,`in`,`e1`),j(e,`intensidad`,t),`long`));let a=O(`div`,`rev-row2`);a.append(A(e,`in`,`e2`),j(e,`tiempo`,t)),i.appendChild(a);let o=O(`div`,`rev-right`);return o.appendChild(M([A(e,`out`,`sal`),A(e,`out`,`sal2`)])),r.append(i,o),n.append(r,I()),n}function Te(e,t){let n=F(e);n.appendChild(L(`Entradas`,`Salidas`));let r=O(`div`,`mod-body int-body`),i=O(`div`,`int-left`);i.appendChild(j(e,`ataque`,t));let a=O(`div`,`int-pulse-row`),o=O(`div`,`int-pcol`);o.append(k(`span`,`mini-lbl`,`pulso`),A(e,`in`,`pulso`)),a.append(o,O(`span`,`h-line flex`),j(e,`modo`,t),P(e.id,`manual`,`Disparo manual de pulso`,t)),i.appendChild(a),i.appendChild(j(e,`duracion`,t)),i.appendChild(j(e,`decaimiento`,t));let s=O(`div`,`int-right`),c=O(`div`,`int-out-group`);c.append(k(`span`,`mini-lbl`,`env.`),M([A(e,`out`,`sal`),A(e,`out`,`sal2`)]));let l=O(`div`,`int-out-group`);return l.append(k(`span`,`mini-lbl`,`pulso`),A(e,`out`,`pulsoSal`)),s.append(c,l),r.append(i,s),n.append(r,I()),n}function Ee(e,t){let n=F(e);n.appendChild(L(`Entradas`,`Salidas`));let r=O(`div`,`mod-body osc-body`),i=O(`div`,`osc-main`),a=O(`div`,`osc-left`),o=O(`div`,`osc-frec-top`);o.append(A(e,`in`,`frec`),O(`span`,`diag-line`)),a.append(o,j(e,`frecuencia`,t,{sizeOverride:`lg`}),O(`span`,`v-line short`),j(e,`fino`,t));let s=O(`div`,`osc-right`),c=O(`div`,`osc-waves`);for(let[t,n]of[[`sen`,`∿`],[`tri`,`∧`],[`rampa`,`⩘`],[`cuad`,`⊓`]]){let r=O(`div`,`wave-out`);r.append(O(`span`,`wave-sym`,n),A(e,`out`,t)),c.appendChild(r)}s.append(c,j(e,`ancho`,t,{labelBelow:!0})),i.append(a,s);let l=O(`div`,`osc-bottom`);return l.append(A(e,`in`,`mod`),O(`span`,`h-line`),k(`span`,`osc-mod-lbl`,`modular en frec.`),j(e,`modulador`,t,{showLabel:!1}),j(e,`modoMod`,t)),r.append(i,l),n.append(r,I()),n}function De(e,t){let n=F(e);n.appendChild(L(`Entradas`,`Salidas`));let r=O(`div`,`mod-body fiv-body`),i=O(`div`,`fiv-left`);i.appendChild(A(e,`in`,`entrada`)),i.appendChild(N(A(e,`in`,`anchoCv`),j(e,`ancho`,t),`long`));let a=O(`div`,`fiv-fader-row`);a.append(k(`span`,`mini-lbl`,`Corte`),j(e,`corte`,t)),i.appendChild(a),i.appendChild(N(A(e,`in`,`control`),j(e,`centro`,t,{sizeOverride:`md`}),`long`));let o=O(`div`,`fiv-mod-block`);o.appendChild(k(`div`,`mini-lbl center`,`modulación`)),o.appendChild(N(A(e,`in`,`mod`),j(e,`modulacion`,t))),o.appendChild(O(`div`,`fader-minmax`,`<span>0</span><span data-i18n="máx.">máx.</span>`)),i.appendChild(o);let s=O(`div`,`fiv-right`);for(let[t,n]of[[`bajos`,`baj.`],[`altos`,`alt.`],[`banda`,`banda`]]){let r=O(`div`,`fiv-out`);r.append(k(`span`,`mini-lbl`,n),A(e,`out`,t)),s.appendChild(r)}return r.append(i,s),n.append(r,I()),n}function Oe(e,t){let n=s[e.type],r=F(e);r.appendChild(L(`Entradas`,`Salidas`));let i=O(`div`,`mod-body fio-body`),a=O(`div`,`fio-left`);a.append(A(e,`in`,`entrada`),k(`span`,`mini-lbl`,`Corte`),j(e,`corte`,t));let o=O(`div`,`bank`);n.params.filter(e=>e.id.startsWith(`g`)).forEach((n,r)=>{let i=O(`div`,`bank-row`);i.append(j(e,n.id,t),O(`span`,`bank-label`,n.label),A(e,`out`,`b${r}`)),o.appendChild(i)});let c=O(`div`,`bank-row bank-sum`);return c.append(k(`span`,`bank-label`,`Suma`),j(e,`suma`,t),A(e,`out`,`suma`)),o.appendChild(c),i.append(a,o),r.append(i,I()),r}function ke(e,t){let n=F(e);n.appendChild(L(`Entradas`,`Salidas`));let r=O(`div`,`mod-body pul-body`),i=O(`div`,`pul-left`),a=O(`div`,`pul-trig-block`);a.append(k(`span`,`mini-lbl`,`inicio`),N(A(e,`in`,`inicio`),P(e.id,`start`,`Iniciar reloj`,t,`pulsador.marcha`),`long`));let o=O(`div`,`pul-trig-block`);o.append(k(`span`,`mini-lbl`,`fin`),N(A(e,`in`,`fin`),P(e.id,`stop`,`Detener reloj`,t),`long`)),i.append(a,o,N(A(e,`in`,`anchoCv`),j(e,`ancho`,t),`long`),N(A(e,`in`,`relojCv`),j(e,`reloj`,t),`long`));let s=O(`div`,`pul-right`);return s.append(k(`span`,`mini-lbl`,`Pulsos`),M([A(e,`out`,`pulsos`),A(e,`out`,`pulsos2`),A(e,`out`,`inv`)])),r.append(i,s),n.append(r,I()),n}function Ae(e,t){let n=F(e,`panel-seq`),r=O(`div`,`seq-body`),i=O(`div`,`seq-left`),a=O(`div`,`seq-top-io`),o=O(`div`,`seq-io-pair`);o.append(k(`span`,`io-title`,`Entradas`),A(e,`in`,`pulso`),k(`span`,`mini-lbl`,`pulsos`));let s=O(`div`,`seq-io-pair`);s.append(k(`span`,`io-title`,`Salida`),A(e,`out`,`pulsoSal`),A(e,`in`,`reinicio`),k(`span`,`mini-lbl`,`reinicio`)),a.append(o,s),i.appendChild(a);let c=O(`div`,`seq-row-jacks`);c.append(A(e,`out`,`a`),A(e,`out`,`b`),A(e,`out`,`c`)),i.appendChild(c);let l=O(`div`,`seq-bot-volt`);l.append(k(`span`,`mini-lbl`,`voltaje`),A(e,`out`,`volt`)),i.appendChild(l);let u=O(`div`,`seq-grid`);for(let t=0;t<10;t++){let n=O(`div`,`seq-head`),r=O(`span`,`led`);r.dataset.step=String(t),n.append(r,A(e,`out`,`st${t}`),O(`span`,`seq-num`,String(t+1))),u.appendChild(n)}for(let n=0;n<3;n++)for(let r=0;r<10;r++)u.appendChild(j(e,`s${n*10+r}`,t));for(let n=0;n<10;n++)u.appendChild(j(e,`sw${n}`,t));return r.append(i,u),n.append(r,I()),n}function je(e,t){let n=F(e,`panel-keys`);n.appendChild(L(void 0,`Salidas`));let r=O(`div`,`keys-outs`);for(let[t,n]of[[`volt`,`Voltaje`],[`pulso`,`Pulso`]]){let i=O(`div`,`jack-wrap out`);i.append(A(e,`out`,t),k(`span`,``,n)),r.appendChild(i)}n.appendChild(r);let i=O(`div`,`controls`);return i.appendChild(j(e,`portamento`,t)),n.appendChild(i),n.appendChild(O(`div`,`keys-hint`,`<span id="keys-hint-text">Teclas <kbd>A</kbd>–<kbd>Ñ</kbd></span><br><kbd>Z</kbd>/<kbd>X</kbd>: <b id="octave-label">C3</b>`)),n.appendChild(O(`div`,`midi`,`<span id="midi-status">MIDI: —</span>`)),n}function Me(e,t){let n=F(e,`panel-out`),r=O(`div`,`out-row`),i=O(`div`,`io-col in`);i.appendChild(k(`div`,`io-title`,`Entradas`));for(let[t,n]of[[`izq`,`Izquierda`],[`der`,`Derecha`]]){let r=O(`div`,`jack-wrap in`);r.append(A(e,`in`,t),k(`span`,``,n)),i.appendChild(r)}return r.append(i,j(e,`volumen`,t)),n.appendChild(r),n.appendChild(O(`div`,`scope-wrap`,`<canvas id="scope" aria-label="Osciloscopio"></canvas>
       <div class="switch-group scope-span">
         <button type="button" data-span="256" data-i18n="Rápida">Rápida</button>
         <button type="button" data-span="1024" data-i18n="Media" class="on">Media</button>
         <button type="button" data-span="2560" data-i18n="Lenta">Lenta</button>
       </div>`)),n}function Ne(e,t){switch(e.type){case`envolvedor`:return be(e,t);case`aleator`:return xe(e);case`anillo`:return Se(e,t);case`ruidor`:return Ce(e);case`reverberal`:return we(e,t);case`integrador`:return Te(e,t);case`oscilador`:return Ee(e,t);case`filtrov`:return De(e,t);case`filtroo`:return Oe(e,t);case`pulsador`:return ke(e,t);case`secuenciador`:return Ae(e,t);case`teclado`:return je(e,t);case`salida`:return Me(e,t);default:return F(e)}}function Pe(e,t){let n=e.getContext(`2d`),r=new Float32Array(4096),i=null,a=1024,o=()=>{let t=window.devicePixelRatio||1;e.width=e.clientWidth*t,e.height=e.clientHeight*t};new ResizeObserver(o).observe(e),o();let s=()=>{let{width:t,height:r}=e;n.strokeStyle=`rgba(120, 255, 170, 0.10)`,n.lineWidth=1,n.beginPath();for(let e=1;e<10;e++)n.moveTo(t*e/10,0),n.lineTo(t*e/10,r);for(let e=1;e<8;e++)n.moveTo(0,r*e/8),n.lineTo(t,r*e/8);n.stroke()},c=()=>{requestAnimationFrame(c);let{width:o,height:l}=e;n.fillStyle=`rgba(6, 18, 12, 0.35)`,n.fillRect(0,0,o,l),s();let u=t(),d=null,f=a;if(u?(r.length!==u.fftSize&&(r=new Float32Array(u.fftSize)),u.getFloatTimeDomainData(r),d=r):i&&i.length>4&&(d=i,f=Math.min(a,i.length)),!d)return;let p=0;for(let e=1;e<d.length-f;e++)if(d[e-1]<0&&d[e]>=0){p=e;break}n.lineWidth=2*(window.devicePixelRatio||1),n.strokeStyle=`#7dffb0`,n.shadowColor=`#3dff8a`,n.shadowBlur=8,n.beginPath();for(let e=0;e<f;e++){let t=e/(f-1)*o,r=l/2-d[p+e]*l*.45;e===0?n.moveTo(t,r):n.lineTo(t,r)}n.stroke(),n.shadowBlur=0};return requestAnimationFrame(c),{setSpan:e=>{a=e},pushSamples:e=>{i&&i.length===e.length||(i=new Float32Array(e.length));for(let t=0;t<e.length;t++)i[t]=e[t]}}}var Fe=`omnifon:modular:v4`,Ie=`omnifon:lang`,R=window.__JUCE__?.backend,z=!!R;z&&document.body.classList.add(`vst-mode`,`powered`);function B(e,t={}){R&&R.emitEvent(`__juce__invoke`,{name:`omnifon`,params:[e,JSON.stringify(t)],resultId:0})}var V=localStorage.getItem(Ie)===`en`?`en`:`es`;se(V);function Le(e){let t={};for(let n of c)t[n.id]={...l(n.type),...e.values[n.id]??{}};return t}var H=(()=>{try{return JSON.parse(localStorage.getItem(Fe)??`null`)}catch{return null}})(),U=H?.patch??y[0].id,Re=y.find(e=>e.id===U)??y[0],W=Le(Re);if(H)for(let e in H.values)W[e]&&Object.assign(W[e],H.values[e]);var ze=H?.cables??ee(Re),G=new ie,Be=null,K=()=>localStorage.setItem(Fe,JSON.stringify({values:W,cables:Be?.cables??[],patch:U})),q={values:W,setters:{},langHooks:[],onParam:(e,t,n)=>{W[e][t]=n,z?B(`setParam`,{mod:e,id:t,v:n}):G.set(e,t,n),K()},onTrigger:(e,t,n)=>{z?B(`trigger`,{mod:e,action:t,down:n}):(G.running||Z(),e===`integrador`&&t===`manual`&&G.send(e,{type:n?`press`:`release`}),e===`pulsador`&&n&&G.send(e,{type:t}))}},Ve=document.getElementById(`cabinet`),He=document.getElementById(`keybed`);for(let e of c){let t=Ne(e,q);e.id===`teclado`?He.prepend(t):e.id===`salida`?He.append(t):Ve.appendChild(t)}var Ue=document.getElementById(`instrument`),J=new oe(Ue,{onConnect:e=>{z?B(`connect`,{from:e.from,to:e.to}):G.connect(e),K()},onDisconnect:e=>{z?B(`disconnect`,{to:e.to}):G.disconnect(e),K()}});Be=J,J.set(ze),document.fonts?.ready.then(()=>J.render());var Y=document.getElementById(`power`),We=document.getElementById(`power-label`);function X(){let e=f[V];We.textContent=G.running?e.powerOff:e.powerOn}async function Z(){if(!G.running)try{await G.start(W,J.cables),document.body.classList.add(`powered`),Y.setAttribute(`aria-pressed`,`true`),X(),ft()}catch(e){console.error(e),alert(f[V].audioError+e.message)}}Y.addEventListener(`click`,async()=>{G.running?(G.send(`teclado`,{type:`allOff`}),await G.ctx?.suspend(),document.body.classList.remove(`powered`),Y.setAttribute(`aria-pressed`,`false`),X()):await Z()});var Ge=[...document.querySelectorAll(`.led[data-step]`)];G.on(`secuenciador`,e=>{e.type===`step`&&Ge.forEach((t,n)=>t.classList.toggle(`on`,n===e.value))}),G.on(`pulsador`,e=>{e.type===`running`&&document.querySelector(`[data-lamp="pulsador.marcha"]`)?.classList.toggle(`on`,!!e.value)});var Ke=document.getElementById(`patches`),qe=document.getElementById(`patch-desc`),Je=document.getElementById(`clear-cables`);function Ye(){let e=y.find(e=>e.id===U);qe.textContent=e?e.description[V]:f[V].unpatchedDesc,Je.classList.toggle(`on`,U===`unpatched`)}function Xe(){Ke.querySelectorAll(`button`).forEach(e=>e.classList.toggle(`on`,e.dataset.patch===U)),Ye()}function Ze(e){U=e.id;let t=Le(e);for(let e in t)for(let n in t[e])W[e][n]=t[e][n],q.setters[`${e}.${n}`]?.(t[e][n]),z||G.set(e,n,t[e][n]);let n=ee(e);if(z){let t=y.findIndex(t=>t.id===e.id);t>=0&&B(`loadPatch`,{index:t})}else J.cables.forEach(e=>G.disconnect(e)),n.forEach(e=>G.connect(e));J.set(n),Xe(),K()}Je.addEventListener(`click`,()=>{U=`unpatched`,z?B(`clearCables`):J.cables.forEach(e=>G.disconnect(e)),J.set([]),Xe(),K()});for(let e of y){let t=document.createElement(`button`);t.type=`button`,t.dataset.patch=e.id,t.textContent=e.name[V],t.title=e.description[V],t.addEventListener(`click`,()=>Ze(e)),Ke.appendChild(t)}Xe();var Qe=document.getElementById(`toggle-cables`);Qe.addEventListener(`click`,()=>{let e=Ue.classList.toggle(`cables-faded`);Qe.classList.toggle(`on`,e)});var Q=document.getElementById(`info-modal`),$=document.getElementById(`manual-modal`),$e=`./fig-iv-38.jpg`,et=`./omnifon-hardware.jpg`;function tt(){Q.innerHTML=p(V,$e),Q.querySelector(`[data-close-modal]`)?.addEventListener(`click`,()=>Q.close()),Q.querySelector(`[data-load-fig]`)?.addEventListener(`click`,()=>{Ze(y[0]),Q.close()})}function nt(){$.innerHTML=m(V,et),$.querySelector(`[data-close-modal]`)?.addEventListener(`click`,()=>$.close())}document.getElementById(`open-info`).addEventListener(`click`,()=>{tt(),Q.showModal()}),document.getElementById(`open-manual`).addEventListener(`click`,()=>{nt(),$.showModal()}),Q.addEventListener(`click`,e=>{e.target===Q&&Q.close()}),$.addEventListener(`click`,e=>{e.target===$&&$.close()});function rt(e){V=e,localStorage.setItem(Ie,V),document.documentElement.lang=V,se(V);let t=f[V];document.getElementById(`brand-subtitle`).textContent=t.subtitle,document.getElementById(`credit-by`).textContent=t.byLabel,document.getElementById(`presets-label`).textContent=t.presets,document.getElementById(`info-label`).textContent=t.info;let n=document.getElementById(`manual-label`);n&&(n.textContent=`Manual`),Qe.textContent=t.dimCables,Je.textContent=t.clearCables,document.getElementById(`footer-credits`).innerHTML=t.footerHtml,X(),Ye();let r=document.getElementById(`keys-hint-text`);r&&(r.innerHTML=V===`en`?`Keys <kbd>A</kbd>–<kbd>;</kbd>`:`Teclas <kbd>A</kbd>–<kbd>Ñ</kbd>`),document.querySelectorAll(`[data-i18n]`).forEach(e=>{e.textContent=d(e.dataset.i18n,V)}),document.querySelectorAll(`.jack[data-jack-label]`).forEach(e=>{let t=e.dataset.dir===`in`?`entrada`:`salida`;e.title=`${d(e.dataset.jackLabel,V)} (${d(t,V)})`}),q.langHooks.forEach(e=>e()),Ke.querySelectorAll(`button`).forEach(e=>{let t=y.find(t=>t.id===e.dataset.patch);t&&(e.textContent=t.name[V],e.title=t.description[V])}),document.querySelectorAll(`#lang-switch button`).forEach(e=>e.classList.toggle(`on`,e.dataset.lang===V)),Q.open&&tt(),$.open&&nt(),requestAnimationFrame(()=>J.render())}document.querySelectorAll(`#lang-switch button`).forEach(e=>{e.addEventListener(`click`,()=>rt(e.dataset.lang))}),rt(V);var it=ve(document.getElementById(`keyboard`),{noteOn:e=>{z?B(`noteOn`,{note:e}):G.running?G.send(`teclado`,{type:`noteOn`,note:e}):Z().then(()=>G.send(`teclado`,{type:`noteOn`,note:e}))},noteOff:e=>{z?B(`noteOff`,{note:e}):G.send(`teclado`,{type:`noteOff`,note:e})}}),at=document.getElementById(`toggle-keyboard`);at&&at.addEventListener(`click`,()=>{let e=document.body.classList.toggle(`kb-hidden`);at.classList.toggle(`on`,!e),z&&B(`toggleKeyboard`,{visible:!e}),requestAnimationFrame(()=>J.render())});var ot=document.getElementById(`daw-sync-btn`),st=document.getElementById(`daw-div-select`),ct=document.getElementById(`daw-transport-btn`),lt=document.getElementById(`daw-bpm-badge`);ot&&ot.addEventListener(`click`,()=>{B(`dawSync`,{enabled:ot.classList.toggle(`on`)})}),st&&st.addEventListener(`change`,()=>{B(`dawDiv`,{index:Number(st.value)})}),ct&&ct.addEventListener(`click`,()=>{B(`dawTransport`,{enabled:ct.classList.toggle(`on`)})}),z&&document.addEventListener(`click`,e=>{let t=e.target?.closest(`a[target="_blank"]`);t?.href&&(e.preventDefault(),B(`openUrl`,{url:t.href}))});var ut=Pe(document.getElementById(`scope`),()=>G.analyser);document.querySelectorAll(`[data-span]`).forEach((e,t,n)=>e.addEventListener(`click`,()=>{ut.setSpan(Number(e.dataset.span)),n.forEach(t=>t.classList.toggle(`on`,t===e))})),window.__omnifonFromHost=e=>{typeof e.step==`number`&&Ge.forEach((t,n)=>t.classList.toggle(`on`,n===e.step)),typeof e.bpm==`number`&&lt&&(lt.textContent=`${e.bpm.toFixed(1)} BPM${e.playing?` ●`:``}`),Array.isArray(e.scope)&&ut.pushSamples(e.scope)},z&&B(`ready`);var dt=!1;function ft(){!dt&&`requestMIDIAccess`in navigator&&(dt=!0,navigator.requestMIDIAccess().then(e=>{let t=document.getElementById(`midi-status`),n=()=>{let n=0;e.inputs.forEach(e=>{n++,e.onmidimessage=e=>{let[t,n,r]=e.data??[],i=t&240;i===144&&r>0?it.press(n):(i===128||i===144&&r===0)&&it.release(n)}}),t.textContent=n?`MIDI: ${n}`:`MIDI: —`};e.onstatechange=n,n()}).catch(()=>{}))}